import numpy as np
from scipy.integrate import odeint
import math

import P0_GEOMETRY as geometry
import P0_WRITE_DATA as write_data

import PARAMETERS as param
from scipy import constants as const

kB = const.k  # 1.38E-23 # J/K
Rg = const.R  # 8.31 # J/k*mol
NA = const.N_A  # 6.02E23
########################################################################################################################
# Constants and Parameters
T = param.main('T')
R_s = param.main('R_s')
const_a = 1


########################################################################################################################
# dθ/dT function
def GET_FILLING_ANGLE(theta, t, l_k, R_s, z, n0, n_inf, wet_deg):
    new_geometry = geometry.calc_geometry_for_one_filling_angle(theta, wet_deg)
    A = new_geometry[1]
    dV_dTheta = new_geometry[2]
    kappa = new_geometry[3]

    dV_dt = A * (1 - n_inf / n0 * np.exp(0.5 * l_k / R_s * kappa))
    d = dV_dt / dV_dTheta
    return d


def GET_FILLING_ANGLE_SA(theta, t, l_k, R_s, z, n0, n_inf, wet_deg):
    new_geometry = geometry.calc_geometry_for_one_filling_angle_SA(theta, wet_deg)
    A = new_geometry[1]
    dV_dTheta = new_geometry[2]
    kappa = new_geometry[3]

    dV_dt = A * (1 - n_inf / n0 * np.exp(0.5 * l_k / R_s * kappa))
    d = dV_dt / dV_dTheta
    return d


def GET_REDUCED_N(theta):
    N_new = []
    N = (np.cos(theta) - 1) ** 2 * (2 * np.cos(theta) + 1)
    for i in range(len(N)):
        N_new.append(N[i][0])
    return N_new


def calc_MBE(chem, info_chem, angle_range, wet_deg):
    zeta = info_chem["zeta"]
    n_0 = info_chem["n_0"]
    n_inf = info_chem["n_inf"]
    l_k = info_chem["l_k"]
    R_s = info_chem["Rs"]
    alpha = info_chem["alpha"]

    t_max = 10
    if chem == 'SA':
        t_max = 1
    t_steps = 1000
    reduced_time = np.linspace(0.00, t_max, t_steps)
    theta_0 = angle_range[0]

    """
    obtain filling angle based on MBE
    """
    geometry.calc_geometry_for_wetting_angle(wet_deg)
    if chem == "SA":
        filling_angle_radian = odeint(GET_FILLING_ANGLE_SA, theta_0, reduced_time,
                                      args=(l_k, R_s, zeta, n_0, n_inf, wet_deg))
    if chem != "SA":
        filling_angle_radian = odeint(GET_FILLING_ANGLE, theta_0, reduced_time,
                                      args=(l_k, R_s, zeta, n_0, n_inf, wet_deg))

    """
    delete angles more than 90 degree
    """
    filling_angle_radian_top = []
    for i in range(len(filling_angle_radian)):
        angle = filling_angle_radian[i][0]
        if angle <= np.pi / 2:
            filling_angle_radian_top.append([angle])
        if angle > np.pi / 2:
            filling_angle_radian_top.append([np.pi / 2])
        if math.isnan(angle):
            filling_angle_radian_top.append([np.pi / 2])

    """
    from radian to degree
    """
    filling_angle_degree = [i[0] * 180 / np.pi for i in filling_angle_radian_top]

    """
    obtain the amount of condensed liquid
    """
    reduced_N = GET_REDUCED_N(filling_angle_radian_top)

    """
    save data reduced units
    """
    file_FILLING_ANGLE = "output/FILLING_ANGLE_without_neck/FOR_" + chem + "_alpha_" + str(alpha) + "_wet_" + str(
        round(wet_deg, 3)) + "_REDUCED_DATA.txt"
    write_data.two_columns(reduced_time, filling_angle_degree, file_FILLING_ANGLE)

    file_REDUCED_N = "output/COND_AMOUNT_without_neck/FOR_" + chem + "_alpha_" + str(alpha) + "_wet_" + str(
        round(wet_deg, 3)) + "_REDUCED_DATA.txt"
    write_data.two_columns(reduced_time, reduced_N, file_REDUCED_N)

    """
    save data non_reduced units
    """
    time_const = 1 / 4 * const_a * info_chem["v_t"] * n_0 / info_chem["n_l"] / R_s
    NON_reduced_time = reduced_time / time_const
    n_const = 2 / 3 * np.pi * info_chem["n_l"] * R_s ** 3
    NON_reduced_N = np.array(reduced_N) * n_const

    file_FILLING_ANGLE_nonred = "output/FILLING_ANGLE_without_neck/FOR_" + chem + "_alpha_" + str(
        alpha) + "_wet_" + str(round(wet_deg, 3)) + "_nonREDUCED_DATA.txt"
    write_data.two_columns(NON_reduced_time, filling_angle_degree, file_FILLING_ANGLE_nonred)

    file_REDUCED_N_nonred = "output/COND_AMOUNT_without_neck/FOR_" + chem + "_alpha_" + str(alpha) + "_wet_" + str(
        round(wet_deg, 3)) + "_nonREDUCED_DATA.txt"
    write_data.two_columns(NON_reduced_time, NON_reduced_N, file_REDUCED_N_nonred)

    # save data HALF reduced units
    file_REDUCED_N_halfred = "output/COND_AMOUNT_without_neck/FOR_" + chem + "_alpha_" + str(alpha) + "_wet_" + str(
        round(wet_deg, 3)) + "_halfREDUCED_DATA.txt"
    write_data.two_columns(NON_reduced_time, reduced_N, file_REDUCED_N_halfred)


# dR/dT function
def GET_FILLING_RADII(radii, t, l_k, R_s, z, n0, n_inf):
    # Kappa
    kappa = 2 / radii
    dR_dt = (1 - n_inf / n0 * np.exp(0.5 * l_k / R_s * kappa))
    return dR_dt


def GET_REDUCED_N_sph(radii):
    N_new = []
    N = (radii ** 3 - 1.0) * 2
    for i in range(len(N)):
        N_new.append(N[i][0])
    return N_new


def radii_to_angle(radii):
    Rs = 1
    set_angle = []
    for Rl in radii:
        Rh = ((Rl) ** 2 - Rs ** 2) ** 0.5
        T = np.arcsin(Rh / Rs)
        if T <= np.pi / 2:
            set_angle.append(T / np.pi * 180)
        if T > np.pi / 2:
            set_angle.append(np.pi / 2)
    return np.array(set_angle)


def find_exit_angle(x, y, time):
    exit_i = 0
    count = 0
    for i in range(len(x)):
        if x[i] >= time and count == 0:
            exit_i = i
            count += 1
    exit_angle = y[exit_i]
    return exit_angle


def calc_MBE_sph(chem, info_chem):
    zeta = info_chem["zeta"]
    n_0 = info_chem["n_0"]
    n_inf = info_chem["n_inf"]
    l_k = info_chem["l_k"]
    R_s = info_chem["Rs"]
    alpha = info_chem["alpha"]

    t_max = 1
    t_steps = 100000
    reduced_time = np.linspace(0.00, t_max, t_steps)
    radii_0 = 1.0

    filling_radii = odeint(GET_FILLING_RADII, radii_0, reduced_time,
                           args=(info_chem["l_k"], R_s, zeta, n_0, n_inf))

    """
        obtain the amount of condensed liquid
    """
    # reduced_N = GET_REDUCED_N_sph(filling_radii)

    filling_radii_mod = []
    for i in filling_radii:
        filling_radii_mod.append(i[0])

    """
    save data reduced units
    """
    file_FILLING_RADII = "output/FILLING_RADII_without_neck/" + "FOR_" + chem + "_alpha_" + str(
        alpha) + "_sph_REDUCED_DATA.txt"
    write_data.two_columns(reduced_time, filling_radii_mod, file_FILLING_RADII)
    """
    save data non_reduced units
    """
    time_const = 1 / 4 * const_a * info_chem["v_t"] * n_0 / info_chem["n_l"] / R_s
    # print(" time const for non reduced", round(time_const, 3))
    NON_reduced_time = reduced_time / time_const
    n_const = 2 / 3 * np.pi * info_chem["n_l"] * R_s ** 3
    # NON_reduced_N = np.array(reduced_N) * n_const

    file_FILLING_RADII_nonred = "output/FILLING_RADII_without_neck/" + "FOR_" + chem + "_alpha_" + str(
        alpha) + "_sph_nonREDUCED_DATA.txt"
    write_data.two_columns(NON_reduced_time, filling_radii_mod, file_FILLING_RADII_nonred)

    # print("filling radii")
    filling_ang = radii_to_angle(filling_radii_mod)  # degree
    L = len(filling_ang)
    NON_reduced_time = NON_reduced_time[:L]

    # radian
    exit_angle = find_exit_angle(NON_reduced_time, filling_ang, 25)
    filling_angle_degree = []
    filling_ang = list(filling_ang)
    for i in filling_ang:
        new_i = i
        if new_i > 90:
            new_i = 90
            filling_angle_degree.append(new_i)
        if new_i <= 90:
            filling_angle_degree.append(new_i)
    filling_angle_degree = np.array(filling_angle_degree)
    # filling_angle_degree = np.array(filling_ang) / np.pi * 180

    # neck.main2(alpha, chem, [NON_reduced_time,filling_angle_degree], 10)
    file_FILLING_angle_nonred = "output/FILLING_RADII_without_neck/" + "FOR_" + chem + "_alpha_" + str(
        alpha) + "_sph_nonREDUCED_DATA_angle.txt"
    write_data.two_columns(NON_reduced_time, filling_angle_degree, file_FILLING_angle_nonred)


########################################################################################################################
def main(chem, chem_info, set_proc, wetting_angle_deg):
    for process in set_proc:
        print(process)
        if process[0] == 'COND':
            print("->consider process ")
            print("        ...", process)
            if chem == "SA":
                calc_MBE_sph(chem, chem_info)
            angle_range = [process[1], process[2]]
            calc_MBE(chem, chem_info, angle_range, wetting_angle_deg)
