import numpy as np
import P0_GEOMETRY as geometry
from scipy import constants as const

kB = const.k  # 1.38E-23 # J/K
Rgas = const.R  # 8.31 # J/k*mol
N_A = const.N_A  # 6.02E23

#####################################################################################################################
#####################################################################################################################
"""
function finds x, where y = 0 
"""


def find_zero(y):
    fix_j = len(y) - 1
    for j in range(len(y) - 1):
        if y[j] >= 0 and y[j + 1] <= 0:
            fix_j = j
    return fix_j


def gap_case(info_chem, wetting_angle_deg):
    l_k = info_chem["l_k"]
    n_inf = info_chem["n_inf"]
    n0 = info_chem["n_0"]
    R_s = info_chem["Rs"]

    # angle range
    min_angle = 0.001
    angle_steps = 100
    filling_angle_rad = np.linspace(min_angle, np.pi / 2, angle_steps)
    # print("analysis of the angle from ", min_angle, " till 90 degree with step ", angle_steps)

    set_kappa = geometry.kappa_for_multi_angles(filling_angle_rad, wetting_angle_deg)

    # part of MBE
    y = list(n0 - n_inf * np.exp(0.5 * l_k / R_s * set_kappa))
    process = []
    if y[0] >= min_angle and y[-1] >= min_angle:
        print("     only CONDENSATION")
        process.append(["COND", min_angle, np.pi / 2])
    if y[0] < min_angle and y[-1] < min_angle:
        print("     only EVAPORATION ")
        process.append(["EVAP", np.pi / 2, min_angle])
    if (y[0] < min_angle and y[-1] >= min_angle) or (y[0] >= min_angle and y[-1] < min_angle):
        zero = find_zero(y)
        if zero >= len(y) - 2:
            print("     only CONDENSATION")
            process.append(["COND", min_angle, np.pi / 2])
        if zero < len(y) - 2:
            critical_theta = list(filling_angle_rad)[zero]
            print("     EVAPORATION/CONDENSATION, critical angle = ",
                  round(critical_theta / (np.pi / 2) * 90, 1),
                  "(degree) ", round(critical_theta, 3), "(radian)")
            process.append(["COND", min_angle, critical_theta])
            process.append(["EVAP", np.pi / 2, critical_theta])

    return process


def main(chem_info, wetting_angle_deg):
    print("->analysis of the processes")
    set_processes = gap_case(chem_info, wetting_angle_deg)
    print("        ... ", set_processes)
    return set_processes
