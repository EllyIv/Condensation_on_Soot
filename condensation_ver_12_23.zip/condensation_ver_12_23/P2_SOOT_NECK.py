import numpy as np
import P0_WRITE_DATA as write_data


def main(alpha, chem, angle_info_0, neck_angle, wetting):
    print("cutting neck...")
    info = angle_info_0

    neck_time = 0
    new_info = []
    for j in range(len(info[:, 1])):
        angle = info[:, 1][j]
        time = info[:, 0][j]
        if angle < neck_angle:
            neck_time = time
        if angle >= neck_angle:
            new_info.append([time - neck_time, angle])
    last_time = new_info[-1][0]
    last_angle = new_info[-1][1]
    if last_time <= 1000:
        add_time = np.arange(last_time, 1000, 0.01)
        for t in add_time:
            new_info.append([t, last_angle])
    new_info = np.array(new_info)
    file_name = "output/FILLING_ANGLE_with_neck/FOR_" + chem + "_alpha_" + str(
        alpha) + "wet_" + str(round(wetting, 3)) + "_nonREDUCED_DATA.txt"
    write_data.two_columns(new_info[:, 0], new_info[:, 1], file_name)
    return new_info

# def main2(alpha, chem, angle_info_0, neck_angle):
#
#     print("cutting neck..." )
#     info = angle_info_0
#
#     neck_time = 0
#     new_info = []
#     for j in range(len(info[1])):
#         angle = info[1][j]
#         time = info[0][j]
#         if angle < neck_angle:
#             neck_time = time
#         if angle >= neck_angle:
#             new_info.append([time - neck_time, angle])
#     last_time = new_info[-1][0]
#     last_angle = new_info[-1][1]
#     if last_time <= 1000:
#         add_time = np.arange(last_time, 1000, 0.01)
#         for t in add_time:
#             new_info.append([t, last_angle])
#     new_info = np.array(new_info)
#
#     file_name = "output/FILLING_RADII_without_neck/" + "FOR_" + chem + "_alpha_" + str(
#         alpha) + "_sph_nonREDUCED_DATA_angle.txt"
#     write_data.two_columns(new_info[:, 0 ], new_info[:, 1] , file_name)
#     return new_info
