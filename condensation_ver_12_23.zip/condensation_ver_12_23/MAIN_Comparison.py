import ALL_constant as const
# import P0_PLOT_DATA as plot_data
import P0_READ_DATA as read_data
import P0_WRITE_DATA as write_data

import P1_MBE as mbe
import P2_SOOT_NECK as neck
import P3_WATER as water
import P4_Gfm_exp as gfm
import matplotlib.colors as mcolors
import numpy as np
import matplotlib.pyplot as plt

import P3__chen2018 as chen2018

import P0_GEOMETRY as geometry

print(3)
config = []

style = {
    'figure.figsize': (10, 8),
    'font.size': 36,
    'axes.labelsize': '26',
    'axes.titlesize': '26',
    'xtick.labelsize': '26',
    'ytick.labelsize': '26',
    'legend.fontsize': '18',
    # 'axes.grid': True,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'lines.linewidth': 2,
    'lines.markersize': 12,
    'xtick.major.size': 18,
    'ytick.major.size': 18,
    'xtick.top': True,
    'ytick.right': True,
    'font.family': 'sans-serif',
    'text.usetex': True
}


#################################################################################################################

#
# def plot():
#      ...
#
#
# set_chem = ["TEG"]
# alpha = 0.9
# neck_angle = 10
# wetting_angle = 27
#
#
# # check Chen 2018
# chen2018.main(neck_angle, wetting_angle)
#

# check  RH


# dict_chem_info = {}
# dict_exit_angle = {}
# for chem in set_chem:
#     dict_chem_info[chem] = ALL_read.read_chem_info(chem, alpha)
#     file_name = "output/exit_angles/neck_"+str(neck_angle) + "_alpha_" + str(alpha)+"_GAP_chem_"+str(chem)+"_wetting_angle_"+str(wetting_angle)+".txt"
#     dict_exit_angle[chem] = float(np.loadtxt(file_name,usecols=[1]))
#
# # print(dict_exit_angle)
# RH = 85
# exit_angle_Kelvin = p56.main(alpha, set_chem, dict_chem_info, neck_angle, dict_exit_angle,  RH, wetting_angle)


def plot_filling_angle_vs_time():
    folder_name = "output/FILLING_ANGLE_with_neck/"
    # set_chem = ["TEG", "TEGMBE", "GA", "AN", "TDA", 'SA']
    set_chem = ["TEG", "TEGMBE", "GA", "AN", "TDA", 'SA', 'PA']
    set_color = ['tab:gray', 'tab:orange', 'tab:blue', 'tab:olive', 'tab:green', 'tab:red', 'tab:pink']
    set_market = ['D', 'o', 'o', '^', 's', 's', 's']
    alpha = 0.9
    # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0, "SA": 0}
    # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0, "SA": 17.2}
    wetting_angle_dic = {'TEG': 7, 'TEGMBE': 7, 'GA': 35, 'AN': 54, 'SA': 34, 'TDA': 0, 'PA': 0}
    filling_angle_dic = {}
    label_x = {'TEG': 0.02, 'TEGMBE': 0.08, 'GA': 5, 'AN': 0.5, 'TDA': 0.002, 'SA': 100, 'PA': 1}
    # label_y = [37,33,14,19, 48.5, 25]
    label_y = {"TEG": 35, "TEGMBE": 41, "GA": 19, "AN": 15, "TDA": 48.5, 'SA': 20, 'PA': 35}
    color_step = 1 / (len(set_chem) + 1)
    c = 0
    fig = plt.figure()
    ax = fig.add_subplot(111)

    for i in set_chem:
        name_f = folder_name + "FOR_" + str(i) + "_alpha_" + str(alpha) + "wet_" + str(
            wetting_angle_dic[i]) + "_nonREDUCED_DATA.txt"
        filling_angle_dic[i] = np.loadtxt(name_f, usecols=[0, 1])
        # plt.plot(filling_angle_dic[i][:, 0], filling_angle_dic[i][:, 1],
        #          label=str(i) + r', $\theta_1 = $' + str(round(filling_angle_dic[i][:, 1][-1], 2)),
        #          color=set_color[c] )
        plt.plot(filling_angle_dic[i][:, 0], filling_angle_dic[i][:, 1],
                 label=str(i), color=set_color[c])
        print(i, round(filling_angle_dic[i][:, 1][-1], 2))
        plt.text(label_x[i], label_y[i], i, fontsize=14, color=set_color[c])
        c = c + 1

    # plt.legend(loc='best')
    plt.xscale('log')
    plt.xlabel(r'Time (s)', fontsize=14)
    plt.ylabel(r'Filling angle, $\theta_1$ (degree)', fontsize=14)
    plt.ylim(ymin=0, ymax=55)
    plt.xlim(xmin=0, xmax=300)
    x = np.arange(0.0, 300, 0.01)
    ax.fill_between(x, 0, 10, alpha=0.2, color='gray')
    ax.set_aspect(1.0 / ax.get_data_ratio(), adjustable='box')
    plt.axvline(x=25, color='k', linestyle='--')
    # plt.axvline(x=8, color='k', linestyle='--')
    # plt.axvline(x=2, color='k', linestyle='--')
    # plt.axvline(x=0.04, color='k', linestyle='--')
    # plt.axvline(x=0.005, color='k', linestyle='--')
    # # plt.axvline(x=3, color='k', linestyle='--')
    plt.axhline(y=10, color='k', linestyle='--')

    plt.text(0.00001, 8, r'carbon neck', fontsize=12)
    # plt.text(25, 40, r'exit-chamber time', fontsize=10, rotation='vertical')
    file_name = "output_plot/FILLING_ANGLE_vs_TIME_alpha_" + str(alpha) + ".pdf"
    plt.savefig(file_name)
    plt.show()


def plot_filling_angle_vs_time_conf():
    folder_name = "output/FILLING_ANGLE_with_neck/"
    # set_chem = ["TEG", "TEGMBE", "GA", "AN", "TDA", 'SA']
    set_chem = ['PA']
    # set_chem = ["TEG", "TEGMBE", "GA", "AN", "TDA", 'SA', 'PA']
    set_color = ['tab:pink']

    # set_color = ['tab:gray', 'tab:orange', 'tab:blue', 'tab:olive','tab:green', 'tab:red', 'tab:pink']
    set_market = ['D', 'o', 'o', '^', 's', 's', 's']
    alpha = 0.9
    # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0, "SA": 0}
    # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0, "SA": 17.2}
    wetting_angle_dic = {'TEG': 7, 'TEGMBE': 7, 'GA': 35, 'AN': 54, 'SA': 34, 'TDA': 0, 'PA': 0}
    filling_angle_dic = {}
    label_x = {'TEG': 0.02, 'TEGMBE': 0.08, 'GA': 5, 'AN': 0.8, 'TDA': 0.002, 'SA': 5, 'PA': 1}
    # label_y = [37,33,14,19, 48.5, 25]
    label_y = {"TEG": 35, "TEGMBE": 41, "GA": 18, "AN": 14, "TDA": 48.5, 'SA': 7, 'PA': 37}
    color_step = 1 / (len(set_chem) + 1)
    c = 0
    fig, ax = plt.subplots()
    ax2 = ax.twinx()
    volume_soot = 4.0 / 3 * np.pi * 1 ** 3
    volume_neck = geometry.calc_volume_for_one_theta(10, 0)

    for i in set_chem:
        name_f = folder_name + "FOR_" + str(i) + "_alpha_" + str(alpha) + "wet_" + str(
            wetting_angle_dic[i]) + "_nonREDUCED_DATA.txt"
        filling_angle_dic[i] = np.loadtxt(name_f, usecols=[0, 1])
        ax.plot(filling_angle_dic[i][:, 0], filling_angle_dic[i][:, 1],
                color='red')

        volume_gap = []
        for j in range(len(filling_angle_dic[i][:, 1])):
            theta = filling_angle_dic[i][:, 1][j]
            volume_gap_with_neck = geometry.calc_volume_for_one_theta(theta, 0)
            volume_gap.append(volume_gap_with_neck - volume_neck)
        volume_gap = np.array(volume_gap)
        volume_fraction = volume_gap / (volume_gap + volume_soot) * 100
        print(volume_fraction[-1])
        ax2.plot(filling_angle_dic[i][:, 0], volume_fraction,
                 color='blue')
        # plt.plot(filling_angle_dic[i][:, 0], filling_angle_dic[i][:, 1],
        #          label=str(i), color=set_color[c])

        # print(i, round(filling_angle_dic[i][:, 1][-1],2))

    limit_vol = geometry.calc_volume_for_one_theta(55, 0) - volume_neck
    limit_fraction = limit_vol / (limit_vol + volume_soot) * 100
    print("limit", limit_fraction)

    plt.xscale('log')
    ax.set_xlabel(r'Time (s)', fontsize=14)
    ax.set_ylabel(r'Filling angle, $\theta_1$ (degree)', fontsize=14, color='red')
    ax2.set_ylabel(r'Volume fraction, %', fontsize=14, color='blue')
    ax.set_ylim(ymin=0, ymax=55)
    ax2.set_ylim(ymin=-1.7, ymax=7.4)
    # ax.set_xlim(xmin=0, xmax=2000)
    # x = np.arange(0.0, 5000, 0.01)
    # ax.fill_between(x, 0, 10, alpha=0.2, color='gray')
    # ax.set_aspect(1.0/ax.get_data_ratio(), adjustable='box')
    plt.axhline(y=10, color='k', linestyle='--')

    file_name = "output_plot/CONF3_PA_FILLING_ANGLE_vs_TIME_alpha_" + str(alpha) + ".pdf"
    plt.savefig(file_name)
    plt.show()


def cut_info(info):
    # print(info)
    new_info = []
    rh_in = 5
    rh_out = 85
    print(len(info))
    info_rh = info[:, 1]
    info_angle = info[:, 0]
    info_rh_new = []
    info_angle_new = []

    for i in range(len(info_rh) - 1):
        if info_rh[i] > rh_in and info_rh[i] < rh_out:
            info_rh_new.append(info_rh[i])
            info_angle_new.append(info_angle[i])
        if info_rh[i] < rh_in and info_rh[i + 1] > rh_in:
            info_rh_new.append(rh_in)
            angle_new = (rh_in - info_rh[i]) / (info_rh[i + 1] - info_rh[i]) * (info_angle[i + 1] - info_angle[i]) + \
                        info_angle[i]
            info_angle_new.append(angle_new)
        if info_rh[i] <= rh_out and info_rh[i + 1] > rh_out:
            info_rh_new.append(rh_out)
            angle_new = (rh_out - info_rh[i]) / (info_rh[i + 1] - info_rh[i]) * (info_angle[i + 1] - info_angle[i]) + \
                        info_angle[i]
            info_angle_new.append(angle_new)

    # return np.array(new_info)
    return [info_rh_new, info_angle_new]


def plot_FIL_ANG_vs_RH():
    folder_name = "output/FILLING_ANGLE_vs_RH/"
    # set_chem = ["TEG", "TEGMBE", "GA", "AN", 'SA']
    # set_color = ['tab:gray', 'tab:orange', 'tab:blue', 'tab:olive',  'tab:red','tab:green']
    set_chem = ["TEGMBE", "TEG", "GA", "AN", 'SA']
    set_color = ['tab:gray', 'tab:blue', 'tab:olive', 'tab:red', 'tab:green']
    alpha = 0.9
    # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0}
    # filling_angle_dic = {}
    # color_step = 1 / (len(set_chem) + 1)
    label_x = {"TEG": 20, "TEGMBE": 60, "GA": 20, "AN": 60, 'SA': 60}
    label_y = {"TEG": 42, "TEGMBE": 44, "GA": 20, "AN": 22, 'SA': 10}
    c = 0
    neck_angle = 10
    RH = 85
    fig = plt.figure()
    ax = fig.add_subplot(111)
    for i in set_chem:
        name_f = folder_name + "chem_" + str(i) + "_neck_" + str(neck_angle) + "_alpha_" + str(alpha) + "_RH_" + str(
            RH) + "_final_angle_GAP"
        info = np.loadtxt(name_f, usecols=[0, 1])
        info = cut_info(info)
        if i != 'GA':
            plt.plot(info[0], info[1], label=str(i), color=set_color[c])
            plt.text(label_x[i], label_y[i], i, fontsize=14, color=set_color[c])
        if i == 'GA':
            new_info_x = [info[0][1], info[0][-1], info[0][-1]]
            new_info_y = [info[1][1], info[1][1], info[1][-1]]
            plt.plot(new_info_x[:], new_info_y[:], label=str(i), color=set_color[c], linestyle='-.')
            plt.text(label_x[i], label_y[i], i, fontsize=14, color=set_color[c])
            # new_info_x = [info[:, 1][0], info[:, 1][-1]]
            # new_info_y = [info[:, 0][0], info[:, 0][-1]]
            # plt.plot(new_info_x, new_info_y, label=str(i), color=set_color[c], linestyle=' ', marker=set_market[c])
        c = c + 1
    # plt.legend(loc='best')
    # plt.xscale('log')
    x = np.arange(0, 90, 0.01)
    ax.fill_between(x, 0, 10, alpha=0.2, color='gray')
    plt.xlabel(r'RH, %', fontsize=12)
    plt.ylabel(r'Filling angle, $\theta_2$ (degree)', fontsize=12)
    plt.ylim(ymin=0, ymax=55)
    plt.xlim(xmin=0, xmax=90)
    ax.set_aspect(1.0 / ax.get_data_ratio(), adjustable='box')

    # plt.axvline(x=85, color='k', linestyle=':')
    # plt.axhline(y=10, color='k', linestyle='-')
    # plt.text(0.00001, 6, r'carbon neck', fontsize=12)
    # plt.text(25, 50, r'exit-chamber time', fontsize=12, rotation='vertical')
    file_name = "output_plot/FILLING_ANGLE_vs_RH_alpha_" + str(alpha) + ".pdf"
    plt.savefig(file_name)
    plt.show()


# def plot_EXI_ANG_vs_GFM():
#     folder_name = "output/EXIT_ANGLE_after_water/"
#     set_chem = ["TEG", "TEGMBE", "GA", "AN"]
#     set_marker = ["o", 's', 'p', '*', 'v']
#     alpha = 0.9
#     # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0}
#     wetting_angle_dic = {'TEG': 7, 'TEGMBE': 7, 'GA': 35, 'AN': 54, 'SA': 34, 'TDA': 0}
#     # filling_angle_dic = {}
#     color_step = 1 / (len(set_chem) + 1)
#     c = 0
#     neck_angle = 10
#     RH = 85
#     for i in set_chem:
#         name_f = folder_name + "neck_"+str(neck_angle)+"_alpha_"+str(alpha)+"_chem_"+str(i)+"_wet_"+str(wetting_angle_dic[i])
#         print(name_f)
#         info = np.loadtxt(name_f, usecols=[1, 2])
#         plt.plot(info[:, 1], info[:, 0], linestyle = ":", marker = set_marker[c], label=str(i), color=(0.0 + c * color_step, 0.5 - c * color_step / 2, 1.0 - c * color_step))
#         c = c + 1
#     plt.legend(loc='best')
#     # plt.xscale('log')
#     plt.ylabel(r'rh')
#     plt.xlabel(r'filling angle (degree)')
#     plt.xlim(xmin=0, xmax=60)
#     # plt.axvline(x=25, color='k', linestyle='--')
#     # plt.axhline(y=10, color='k', linestyle='-')
#     # plt.text(0.00001, 6, r'carbon neck', fontsize=12)
#     # plt.text(25, 50, r'exit-chamber time', fontsize=12, rotation='vertical')
#     # file_name = "output_plot/FILLING_ANGLE_vs_TIME_alpha_" + str(alpha) + ".pdf"
#     # plt.savefig(file_name)
#     plt.show()


def Gfm_SA_sph():
    name_f = "output/FILLING_RADII_without_neck/FOR_SA_alpha_0.9_sph_nonREDUCED_DATA.txt"
    info = np.loadtxt(name_f, usecols=[0, 1])
    info_t = info[:, 0]
    info_r = info[:, 1]
    exit_r = 0
    for t in range(len(info_t) - 1):
        if info_t[t] < 25 and info_t[t + 1] > 25:
            exit_r = info_r[t + 1]
    vol_liq = 4 / 3 * np.pi * (exit_r ** 3 - 1 ** 3)
    # print(vol_liq)
    return vol_liq


def Gfm_last():
    alpha = 0.9
    neck_angle_deg = 10
    set_chem = ["TEG", "TEGMBE", "GA", "AN", 'SA', 'TDA']
    dens_dic = {'TEG': 1.12, 'TEGMBE': 0.99, 'GA': 1.3, 'AN': 1.72, 'SA': 1.60, 'TDA': 0.76}  # dens g/cm-3
    wetting_angle_dic_in = {'TEG': 7, 'TEGMBE': 7, 'GA': 35, 'AN': 54, 'SA': 34, 'TDA': 0}
    # filling_angle_dic_in = {'TEG': 44.47, 'TEGMBE': 44.78, 'GA': 18.08, 'AN': 13.29, 'SA': 10.77, 'TDA': 47.65}
    # filling_angle_dic_out = {'TEG': 50.52, 'TEGMBE': 49.83, 'GA': 23.33, 'AN': 23.09, 'SA': 17.67}
    filling_angle_dic_in = {'TEG': 44.47, 'TEGMBE': 44.78, 'GA': 16.39, 'AN': 13.93, 'SA': 10.77, 'TDA': 47.65}
    # filling_angle_dic_out = {'TEG': 50.52, 'TEGMBE': 49.83, 'GA': 22.34, 'AN': 23.48, 'SA': 17.67}
    # filling_angle_dic_out = {'TEG': 50.52, 'TEGMBE': 47.23, 'GA': 22.34, 'AN': 23.48, 'SA': 17.67}
    wetting_angle_dic_out = {}

    for chem in set_chem:
        volume_neck = geometry.calc_volume_for_one_theta(10, 0)
        volume_in = geometry.calc_volume_for_one_theta(filling_angle_dic_in[chem], wetting_angle_dic_in[chem])
        volume_liq = volume_in - volume_neck  # dimentionless
        dens_soot = 1.77 / 1000 * 10 ** 6  # 1.77  g/cm3
        # print(4 / 3 * np.pi , volume_neck,volume_liq)
        mass_sphere = (4 / 3 * np.pi + volume_neck) * dens_soot
        if chem != 'SA':
            mass_liq = volume_liq * dens_dic[chem] * 1000  # dens kg/m-3
            Gfm = (mass_liq + mass_sphere) / mass_sphere
            print("Gfm  for ", chem, " ", round(Gfm, 4))
        if chem == 'SA':
            # print(volume_liq)
            vol_sph = Gfm_SA_sph() - (volume_neck + volume_liq) / 2
            volume_liq = vol_sph + volume_liq
            mass_liq = volume_liq * dens_dic[chem] * 1000
            Gfm = (mass_liq + mass_sphere) / mass_sphere
            print("Gfm  for ", chem, " ", round(Gfm, 4))


def plot_filling_angle_SA():
    alpha = 0.9
    wetting_angle = 0
    gap = "output/FILLING_ANGLE_with_neck/FOR_SA_alpha_" + str(alpha) + "wet_" + str(
        wetting_angle) + "_nonREDUCED_DATA.txt"
    sph = "output/FILLING_RADII_without_neck/" + "FOR_SA_alpha_" + str(alpha) + "_sph_nonREDUCED_DATA_angle.txt"

    info_gap = np.loadtxt(gap, usecols=[0, 1])
    info_sph = np.loadtxt(sph, usecols=[0, 1])
    print(info_sph[:, 1][0])
    fig = plt.figure()
    ax = fig.add_subplot(111)

    plt.plot(info_gap[:, 0], info_gap[:, 1], label='SA (gap)', color='red')
    plt.plot(info_sph[:, 0], info_sph[:, 1], label='SA (sph)', color='tab:red')

    # print(filling_angle_dic[i][:, 1][-1]

    plt.legend(loc='best')
    plt.xscale('log')
    plt.xlabel(r'Time (s)')
    plt.ylabel(r'Filling angle, $\theta_1$ (degree)')
    plt.ylim(ymin=0, ymax=60)
    plt.xlim(xmin=0, xmax=300)
    ax.set_aspect(1.0 / ax.get_data_ratio(), adjustable='box')
    plt.axvline(x=25, color='k', linestyle='--')
    plt.axhline(y=10, color='k', linestyle='--')

    plt.text(0.00001, 8, r'carbon neck', fontsize=10)
    plt.text(25, 40, r'exit-chamber time', fontsize=10, rotation='vertical')
    # file_name = "output_plot/FILLING_ANGLE_vs_TIME_alpha_" + str(alpha) + ".pdf"
    # plt.savefig(file_name)
    plt.show()


def plot_FIL_ANG_vs_Gfd():
    folder_name = "output/GFD/"
    # set_chem = ["TEG", "TEGMBE", "GA", "AN", 'SA']
    # set_color = ['tab:gray', 'tab:orange', 'tab:blue', 'tab:olive',  'tab:red','tab:green']
    # set_market = ['D', 'o', 'o', '^', 's', 's']
    set_chem = ["TEG", "TEGMBE", "GA", "AN", 'SA']
    set_color = ['tab:gray', 'tab:blue', 'tab:olive', 'tab:red', 'tab:green']
    set_market = ['D', 'o', '^', 's', 's']
    alpha = 0.9
    # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0, "SA": 0}
    # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0, "SA": 17.2}
    wetting_angle_dic = {'TEG': 7, 'TEGMBE': 7, 'GA': 35, 'AN': 54, 'SA': 34, 'TDA': 0}
    # filling_angle_dic = {}

    color_step = 1 / (len(set_chem) + 1)
    c = 0
    neck_angle = 10
    RH = 85
    fig = plt.figure()
    ax = fig.add_subplot(111)
    label_x = {"TEG": 40, "TEGMBE": 35, "GA": 24, "AN": 25, 'SA': 17}
    label_y = {"TEG": 0.9, "TEGMBE": 0.82, "GA": 0.9, "AN": 0.85, 'SA': 0.86}
    for i in set_chem:
        name_f = folder_name + "neck_" + str(neck_angle) + "_alpha_" + str(alpha) + "_chem_" + str(
            i) + "_wet_" + str(wetting_angle_dic[i]) + ".txt"
        info = np.loadtxt(name_f, usecols=[0, 1])
        if i != 'GA':
            plt.plot(info[:, 1], info[:, 0], label=str(i), color=set_color[c], linestyle=':', marker=set_market[c])
            # plt.text(label_x[c], label_y[c], i, fontsize=14, color=set_color[c])
        if i == 'GA':
            new_info_x = [info[:, 1][0], info[:, 1][-1], info[:, 1][-1]]
            new_info_y = [info[:, 0][0], info[:, 0][0], info[:, 0][-1]]
            plt.plot(new_info_x, new_info_y, label=str(i), color=set_color[c], linestyle='-.')
            new_info_x = [info[:, 1][0], info[:, 1][-1]]
            new_info_y = [info[:, 0][0], info[:, 0][-1]]
            plt.plot(new_info_x, new_info_y, label=str(i), color=set_color[c], linestyle=' ', marker=set_market[c])
            # print(info[:, 1], info[:, 0])
        # name_f = folder_name + "neck_"+str(neck_angle)+"_alpha_"+str(alpha)+"_chem_"+str(i)+"_wet_"+str(wetting_angle_dic[i])+".txt"
        # info = np.loadtxt(name_f, usecols=[0, 1])
        # plt.plot(info[:, 1], info[:, 0], label=str(i), color=set_color[c], linestyle = ':', marker= set_market[c])
        plt.text(label_x[i], label_y[i], i, fontsize=14, color=set_color[c])
        c = c + 1
    # plt.legend(loc='best')
    # plt.xscale('log')
    plt.ylabel(r'Gfd', fontsize=14)
    plt.xlabel(r'Filling angle, $\theta_2$ (degree)', fontsize=14)
    # plt.ylim(ymin=0, ymax=60)
    ax.set_aspect(1.0 / ax.get_data_ratio(), adjustable='box')
    # plt.axvline(x=25, color='k', linestyle='--')
    # plt.axhline(y=10, color='k', linestyle='-')
    # plt.text(0.00001, 6, r'carbon neck', fontsize=12)
    # plt.text(25, 50, r'exit-chamber time', fontsize=12, rotation='vertical')
    file_name = "output_plot/FILLING_ANGLE_vs_GFD_alpha_" + str(alpha) + ".pdf"
    plt.savefig(file_name)
    plt.show()


def calc_wet_angle(RH, chem):
    dict_w_TEG = {'out': 0.529, 'in': 1}
    dict_w_TEGMBE = {'out': 0.80457, 'in': 1}
    dict_w_SA = {'out': 0.176, 'in': 0.65}
    dict_w_AN = {'out': 0.671, 'in': 1}
    dict_w_GA = {'out': 0.475, 'in': 1}

    if chem == "TEG":
        c_m = dict_w_TEG[RH]
        wet_new = (c_m - 1) / (0.529 - 1) * (38 - 7) + 7
    if chem == "TEGMBE":
        c_m = dict_w_TEGMBE[RH]
        wet_new = (c_m - 1) / (0.80457 - 1) * (38 - 7) + 7
        # print("klklk0", wet_new)
    if chem == "SA":
        c_m = dict_w_SA[RH]
        wet_new = (c_m - 0.65) / (0.176 - 0.65) * (48.9 - 34) + 34
    if chem == "AN":
        c_m = dict_w_AN[RH]
        wet_new = (c_m - 1) / (0.6707 - 1) * (49 - 54) + 54
    if chem == "GA":
        c_m = dict_w_GA[RH]
        wet_new = (c_m - 1) / (0.4752 - 1) * (31 - 35) + 35
    return wet_new


def Gfv_after_water():
    alpha = 0.9
    neck_angle = 10

    # folder_name_in = "output/EXIT_ANGLE_after_chamber/"
    # folder_name_out = "output/EXIT_ANGLE_after_water/"
    folder_name = "output/FILLING_ANGLE_vs_RH/"
    set_RH = ['out']
    for rh in set_RH:
        geometry.calc_geometry_for_wetting_angle(calc_wet_angle(rh, 'TEG'))
        geometry.calc_geometry_for_wetting_angle(calc_wet_angle(rh, 'TEGMBE'))
        geometry.calc_geometry_for_wetting_angle(calc_wet_angle(rh, 'SA'))
        geometry.calc_geometry_for_wetting_angle(calc_wet_angle(rh, 'GA'))
        geometry.calc_geometry_for_wetting_angle(calc_wet_angle(rh, 'AN'))
    wetting_angle_dic_in = {'TEG': 7, 'TEGMBE': 7, 'GA': 35, 'AN': 54, 'SA': 34, 'TDA': 0}
    # filling_angle_dic_in = {'TEG': 44.47, 'TEGMBE': 44.78, 'GA': 18.08, 'AN': 13.29, 'SA': 10.77, 'TDA': 47.65}
    # filling_angle_dic_out = {'TEG': 50.52, 'TEGMBE': 49.83, 'GA': 23.33, 'AN': 23.09, 'SA': 17.67}
    filling_angle_dic_in = {'TEG': 44.47, 'TEGMBE': 44.78, 'GA': 16.39, 'AN': 13.93, 'SA': 10.77, 'TDA': 47.65}
    # filling_angle_dic_out = {'TEG': 50.52, 'TEGMBE': 49.83, 'GA': 22.34, 'AN': 23.48, 'SA': 17.67}
    # filling_angle_dic_out = {'TEG': 51.52, 'TEGMBE': 47.38, 'GA': 22.34, 'AN': 23.48, 'SA': 17.67}
    filling_angle_dic_out = {'TEG': 51.52, 'TEGMBE': 47.38, 'GA': 28.24, 'AN': 19.43, 'SA': 26.72}
    wetting_angle_dic_out = {}

    set_chem = ["TEGMBE", "TEG", "GA", "AN", 'SA']

    for chem in set_chem:
        for r in set_RH:
            wet_angle_new = calc_wet_angle(r, chem)
            wetting_angle_dic_out[chem] = wet_angle_new
        vol_neck = geometry.calc_volume_for_one_theta(10, 0)
        vol_in = geometry.calc_volume_for_one_theta(filling_angle_dic_in[chem], wetting_angle_dic_in[chem])
        vol_out = geometry.calc_volume_for_one_theta(filling_angle_dic_out[chem], wetting_angle_dic_out[chem])
        if chem != 'SA':
            Gfv = (vol_out - vol_neck) / (vol_in - vol_neck)
        if chem == 'SA':
            vol_sph = Gfm_SA_sph() - (vol_out) / 2
            print(vol_out, vol_neck, vol_sph)
            Gfv = (vol_out - vol_neck + vol_sph) / (vol_in - vol_neck + vol_sph)
        print(chem, Gfv)
        print(",,,,")

    # wetting_angle_dic = {"TEG": 27, "TEGMBE": 27, "GA": 35, "AN": 54, "TDA": 0, "SA": 17.2}
    # wetting_angle_dic = {'TEG': 7, 'TEGMBE': 7, 'GA': 35, 'AN': 54, 'SA': 34, 'TDA': 0}

    # wetting_angle_with_water = {"TEG": 50.52, "GA": 23.33, "AN":  23.82,  "SA": 17.67}
    # geometry.calc_geometry_for_wetting_angle(wetting_angle_with_water["TEG"])
    # geometry.calc_geometry_for_wetting_angle(wetting_angle_with_water["SA"])
    # geometry.calc_geometry_for_wetting_angle(wetting_angle_with_water["GA"])
    # geometry.calc_geometry_for_wetting_angle(wetting_angle_with_water["AN"])
    # for i in set_chem:
    #     wet_angle = wetting_angle_dic_in[i]
    #     # name_f_in = folder_name_in + "neck_" + str(neck_angle) + "_alpha_" + str(alpha) + "_chem_" + str(
    #     #     i) + "_wet_" + str(wetting_angle_dic[i]) + ".txt"
    #     # name_f_out = folder_name_out + "neck_" + str(neck_angle) + "_alpha_" + str(alpha) + "_chem_" + str(
    #     #     i) + "_wet_" + str(wetting_angle_dic[i])
    #     name_f = folder_name + "chem_"+str(i)+"_neck_" + str(neck_angle) + "_alpha_" + str(alpha)+"_RH_85_final_angle_GAP"
    #
    #     # file_in = open(name_f_in , 'r')
    #     # line_in = file_in.readlines()
    #     # angle_in = float(line_in[0].split()[1])/180*np.pi
    #     #
    #     # file_out = open(name_f_out, 'r')
    #     # line_out = file_out.readlines()
    #     # angle_out = float(line_out[-1].split()[2])/180*np.pi
    #
    #     file = open(name_f, 'r')
    #     line = file.readlines()
    #     print("angle: ", float(line[0].split()[0]), float(line[-1].split()[0]))
    #     angle_1 = float(line[0].split()[0]) / 180 * np.pi
    #     angle_2 = float(line[-1].split()[0]) / 180 * np.pi
    #
    #
    #
    #     # print("angle: ", angle_in, angle_out)
    #     print("angle: ", round(angle_1,2), round(angle_2,2))
    #     neck_rad = neck_angle / 180 * np.pi
    #     V_in = geometry.calc_geometry_for_one_filling_angle(angle_1, wet_angle)[4]
    #     V_out = geometry.calc_geometry_for_one_filling_angle(angle_2, wetting_angle_dic_out[i])[4]
    #     V_neck = geometry.calc_geometry_for_one_filling_angle(neck_rad, 0)[4]
    #     Gfv  = (V_out- V_neck)/ (V_in- V_neck)
    #
    #     print("for ", i , " Gfv is ", round(Gfv,2))





# plot_filling_angle_vs_time()
# plot_filling_angle_vs_time_conf()
# plot_FIL_ANG_vs_Gfd()

"""
plot_FIL_ANG_vs_RH()
Gfm_last()
#plot_filling_angle_SA()
plot_FIL_ANG_vs_Gfd()
Gfv_after_water()
"""
