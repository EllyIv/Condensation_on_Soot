import numpy as np
import P0_GEOMETRY as geom
from scipy import constants as const

k_B = const.k  # 1.38E-23 # J/K
R_g = const.R  # 8.31 # J/k*mol
N_A = const.N_A  # 6.02E23


def main(alpha, chem, neck_angle_deg, wetting_angle_deg, dens):
    # exit angle for chem
    name_file = "output/EXIT_ANGLE_after_chamber/neck_" + str(neck_angle_deg) + "_alpha_" + str(alpha) + "_chem_" + str(
        chem) + "_wet_" + str(wetting_angle_deg) + ".txt"
    file = open(name_file, 'r')
    line0 = file.readlines()[0]
    angle = float(line0.split(' ')[1])

    # volume for filling angle
    angle_rad = angle / 180 * np.pi
    volume_neck = geom.calc_geometry_for_one_filling_angle(neck_angle_deg / 180 * np.pi, 0)[4]
    volume = geom.calc_geometry_for_one_filling_angle(angle_rad, wetting_angle_deg)[4]
    volume_liq = volume - volume_neck  # dimentionless
    # Rs = const.main('R_s')
    mass_liq = volume_liq * dens  # dens kg/m-3

    dens_soot = 1.77 / 1000 * 10 ** 6  # 1.77  g/cm3
    mass_sphere = (4 / 3 * np.pi + volume_neck) * dens_soot
    Gfm = mass_liq / mass_sphere * 100
    print("Gfm  for ", chem, " ", Gfm)

    name_new = "output/GFM/neck_" + str(neck_angle_deg) + "_alpha_" + str(alpha) + "_chem_" + str(chem) + "_wet_" + str(
        wetting_angle_deg) + ".txt"
    file1 = open(name_new, 'w')
    file1.writelines(str(chem) + " " + str(Gfm) + "\n")
    file1.close()
