import numpy as np
from sympy import *
import P0_GEOMETRY as geometry


def write_final_angle(set_exit_angles, chem, neck_angle, alpha, wet_angle):
    RH = [5, 20, 40, 65, 85]
    f = open("output/EXIT_ANGLE_after_water/neck_" + str(neck_angle) + "_alpha_" + str(
        alpha) + "_chem_" + chem + "_wet_" + str(wet_angle), "w")
    for i in range(len(RH)):
        line = str(RH[i]) + " " + str(set_exit_angles[0][i]) + " " + str(set_exit_angles[1][i]) + "\n"
        f.write(line)
    f.close()


"""
plot filling angle after Gfd
"""


def plot_final_angle(initial_angle, final_angle, Gfd, chem):
    # plt.clf()
    final_rh_angle = {}

    set_markers = ["s", "o", "v", "p", "*"]
    RH = [5, 20, 40, 65, 85]

    Gfd_data = find_gfX(chem, Gfd)
    angle_data = np.array(final_angle) / np.pi * 180

    # plt.plot(angle_data, RH, linestyle='--', label=chem, markersize=5)
    # plt.plot( angle_data, Gfd_data,linestyle='--', label=chem, markersize=5)
    #
    # plt.xlabel(r'filling angle')
    # plt.ylabel(r'Gfd')
    # plt.legend(loc='best')
    # plt.show()
    return [Gfd_data, angle_data]


"""
read info from file 
"""


def read_exit_angle(file_initial_angle):
    file = open(file_initial_angle, 'r')
    line = file.readlines()

    angle = line[0].split()[1]
    return angle


"""
read info for Gfv or Gfd
"""


def read_GfX(name):
    file = open(name, 'r')
    lines = file.readlines()
    new_lines = []
    chem = []

    for i in range(len(lines)):
        # print(lines[i][:-1].split(" "))
        line = lines[i][:-1].split("\t")[1:]
        mod_line = []
        if i != 0:
            for j in line:
                mod_line.append(float(j))
            new_lines.append(mod_line)
        if i == 0:
            chem = line
    # print(new_lines)
    # print(chem)

    Gfv_info = []
    for i in range(len(chem)):
        # print("chem", i)
        chem_gfv = []
        line = []
        for t in new_lines:
            # print(t[i])
            line.append(t[i])
        # print(chem[i], line)
        Gfv_info.append([chem[i], line])
    # print(Gfv_info)
    return Gfv_info
    # print(line_0)


"""
find Gfv or Gfd for chem 
"""


def find_gfX(name, Gfx):
    for i in Gfx:
        if name == i[0]:
            return i[1]


def calc_wet(wetting_angle, rh_set):
    # print(wetting_angle)
    a1_water = 55
    a2_liquid = wetting_angle

    a3_mix_set = []
    for rh in rh_set:
        x_water = (rh - 1) / rh
        a3_mix = x_water * (a1_water - a2_liquid) + a2_liquid
        a3_mix_set.append(a3_mix)
    return a3_mix_set


"""
calculate new volume, based on neck and Gfv factor
new volume = old volume - neck  
"""


def calc_final_angle(chem, angle_in, neck_angle, Gfv, wetting_angle):
    neck_angle = neck_angle / 180 * np.pi
    angle_out = []

    theta = float(angle_in) / 180 * np.pi
    rh_set = np.array(find_gfX(chem, Gfv))

    # print(wetting_angle, theta, rh_set)

    V_total = geometry.calc_geometry_for_one_filling_angle(theta, wetting_angle)[4]
    V_neck = geometry.calc_geometry_for_one_filling_angle(neck_angle, 0)[4]
    V_liquid = V_total - V_neck

    set_wet_angle = calc_wet(wetting_angle, rh_set)
    V_RH = V_liquid * rh_set + V_neck
    set_angle_out = []

    # print(set_wet_angle)
    for k in range(len(V_RH)):
        geometry.calc_geometry_for_wetting_angle(set_wet_angle[k])
        angle_out = geometry.calc_filling_angle_for_one_volume_and_wet_angle(V_RH[k], set_wet_angle[k])
        set_angle_out.append(angle_out)
    # print("angle_out", angle_out)
    return set_angle_out


######################################################################
def main(alpha, chem, neck_angle_deg, wetting_angle_deg):
    file_initial_angle = "output/EXIT_ANGLE_after_chamber/neck_" + str(neck_angle_deg) + "_alpha_" + str(
        alpha) + "_chem_" + str(chem) + "_wet_" + str(wetting_angle_deg) + ".txt"
    initial_angle = read_exit_angle(file_initial_angle)
    Gfv_info = read_GfX("input_0/info_Gfv.txt")
    Gfd_info = read_GfX("input_0/info_Gfd.txt")

    angle_out = calc_final_angle(chem, initial_angle, neck_angle_deg, Gfv_info, wetting_angle_deg)

    print("... initial exit angle: ", initial_angle)
    print("... final exit angle: ", angle_out)
    print("... Gfv: ", Gfv_info)
    print("... Gfd: ", Gfd_info)

    """
    plot filling angle after Gfd
    """
    final_angle = plot_final_angle(initial_angle, angle_out, Gfd_info, chem)
    write_final_angle(final_angle, chem, neck_angle_deg, alpha, wetting_angle_deg)
    return final_angle

######################################################################
