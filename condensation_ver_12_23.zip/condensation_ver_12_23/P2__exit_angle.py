import P0_WRITE_DATA as write_data


def find_exit_angle(x, y, time):
    exit_i = 0
    count = 0
    for i in range(len(x)):
        if x[i] >= time and count == 0:
            exit_i = i
            count += 1
    exit_angle = y[exit_i]
    return exit_angle


def main(alpha, chem, angle_info_0, neck_angle, wetting_deg):
    exit_angle = find_exit_angle(angle_info_0[:, 0], angle_info_0[:, 1], 25)
    print("exit_angle", round(exit_angle, 2))
    exit_angles = [chem, round(exit_angle, 2)]

    write_data.write_exit_angle(exit_angles, alpha, neck_angle, wetting_deg, chem)
    return exit_angles[1]
