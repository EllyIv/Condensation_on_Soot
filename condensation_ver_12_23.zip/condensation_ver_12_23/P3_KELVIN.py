import numpy as np
import math
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import rc
import P0_READ_DATA as read_data
import P0_GEOMETRY as geometry

from scipy import constants as const

k_B = const.k  # 1.38E-23 # J/K
R_g = const.R  # 8.31 # J/k*mol
N_A = const.N_A  # 6.02E23

config = []

style = {
    'figure.figsize': (10, 8),
    'font.size': 36,
    'axes.labelsize': '26',
    'axes.titlesize': '26',
    'xtick.labelsize': '26',
    'ytick.labelsize': '26',
    'legend.fontsize': '18',
    # 'axes.grid': True,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'lines.linewidth': 2,
    'lines.markersize': 12,
    'xtick.major.size': 18,
    'ytick.major.size': 18,
    'xtick.top': True,
    'ytick.right': True,
    'font.family': 'serif',
    'text.usetex': True
}
# https://matplotlib.org/users/customizing.html
matplotlib.rcParams.update(style)
markers = ["o", 'X', '^', 'P', 'd', '*', 's', '.', 'x', '>']
rc('text', usetex=True)

# constant
pi = math.pi
k_B = const.k  # 1.38E-23 # J/K
R_g = const.R  # 8.31 # J/k*mol
N_A = const.N_A  # 6.02E23


def find_index(rh, set_rh):
    index = 10
    for i in range(len(set_rh) - 1):
        if (set_rh[i] >= rh and set_rh[i + 1] <= rh) or (set_rh[i] <= rh and set_rh[i + 1] >= rh):
            index = i
    return index


# def write_rh_angle(set_exit_angle, set_chem, file_name):
#     set_fix_RH = [5,20, 40, 65, 85]
#     print(file_name)
#     f = open(file_name, "w")
#
#     first_line = " RH %   "
#     for i in set_chem:
#         first_line = first_line + i +" "
#     f.write(first_line +"\n")
#
#     for rh in set_fix_RH:
#         line = str(rh)
#         for chem in set_chem:
#             angles = set_exit_angle[chem][0]
#             index = find_index(rh, set_exit_angle[chem][2])
#             line = line + " " +str(round(angles[index],3))
#         line = line+"\n"
#         f.write(line)
#     # for chem in set_chem:
#     #     info = set_exit_angle[chem]
#     #     for rh in set_fix_RH:
#     #         for i in set_rh:
#     #
#     #     #set_angles, set_pressure, set_rh
#     #
#     #
#     # for i in range(len(set_exit_angles)):
#     f.close()

def write_file_rh_vs_angle(set_exit_angle, chem, file_name):
    set_angle = set_exit_angle[0]
    set_rh = set_exit_angle[2]

    f = open(file_name, "w")

    for i in range(len(set_angle)):
        line = str(set_angle[i]) + " " + str(set_rh[i]) + "\n"
        f.write(line)
    f.close()

    # [set_angles, set_pressure, set_rh]


def check_rh_range(rh_in, set_angles, set_pressure, set_rh):
    set_rh_in = []
    if min(np.array(set_rh)) > rh_in:
        count = 0
    if min(np.array(set_rh)) < rh_in:
        for i in range(len(set_angles) - 1):
            rh1 = set_rh[i]
            rh2 = set_rh[i + 1]
            if (rh1 <= rh_in and rh2 >= rh_in) or (rh1 >= rh_in and rh2 <= rh_in):
                set_rh_in.append(i)
        count = max(np.array(set_rh_in))
    set_angles = set_angles[count:]
    set_pressure = set_pressure[count:]
    set_rh = set_rh[count:]
    return [set_angles, set_pressure, set_rh]


"""
write information about exit angle into the file 
"""


def write_exit_angle(set_exit_angles, alpha, neck_angle, RH):
    f = open("output/GAP/exit_angles/neck_" + str(neck_angle) + "_alpha_" + str(alpha) + "_RH_" + str(RH) + "_GAP", "w")
    for i in range(len(set_exit_angles)):
        f.write(str(set_exit_angles[i][0]) + " " + str(set_exit_angles[i][1]) + " \n")
    f.close()


def calc_vol(theta):
    theta = float(theta / 180 * np.pi)
    vol = 2 * np.pi * (1 / np.cos(theta) - 1) ** 2 * (1 - np.sin(theta) / np.cos(theta) * (np.pi / 2 - theta))
    return vol


def water_density(T):
    dens_dict = {291: 0.998021, 293: 0.998232, 296: 0.997567, 297: 0.997326, 303: 0.995676, 298: 0.9970}
    return dens_dict[T] * 1000


def calc_lk(chem_info, T, c, chem):
    print("*" * 30)
    mu_water = 18.01528 * 0.001  # kg/mol
    rho_water = water_density(T)  # kg m−3
    gamma_water = 72 * 0.001  # N/m
    V_water = mu_water / rho_water
    lk_water = 2 * gamma_water * V_water / R_g / T
    print('     water', round(mu_water, 4), round(rho_water, 2), round(gamma_water, 4), lk_water, V_water)

    mu = chem_info["mol_mass"]
    rho = chem_info["density"]
    gamma = chem_info["surf_tens"]
    V_m = mu / rho
    lk = 2 * gamma * V_m / R_g / T
    print("     chem ", round(mu, 4), round(rho, 2), round(gamma, 4), lk, V_m)

    # print(c)
    mu_mix = c * mu + (1 - c) * mu_water
    rho_mix = dens_versus_concentration(chem, c)
    # rho_mix = c * rho + (1 - c) * rho_water
    V_mix = mu_mix / rho_mix

    gamma_mix = gamma_versus_concentration(chem, c)
    # if chem == "SA" or chem == "TEG":
    #     gamma_mix = gamma_versus_concentration(chem, c)
    # else:
    #     gamma_mix = c * gamma+(1-c)*gamma_water
    # print("V ",V_mix, V_m)
    # print(mu_mix, rho_mix, gamma_mix)

    # lk_mix = 2 * gamma * V_m / R_g / T
    lk_mix = 2 * gamma_mix * V_mix / R_g / T
    # lk_mix = c * lk+(1-c)*lk_water
    print("     mix", round(mu_mix, 4), round(rho_mix, 2), round(gamma_mix, 4), lk_mix, V_mix)
    # print("TEG ", mu, rho, gamma)
    # mu = data_in[i][0] / 1E3  # kg/mol
    # rho = data_in[i][1] / 1E3 * 1E6  # kg/m3
    # V_m = mu / rho  # molar volume
    # Lk = 2 * gamma *V_m/ R / T
    print("*" * 30)
    return lk_mix


def gamma_versus_concentration(chem, c):
    c = c * 100
    if chem == "TEG" or chem == "TEGMBE":
        gamma = -1.4161 * 10 ** (-5) * c ** 3 + 0.0040542 * c ** 2 - 0.52255 * c + 71.25
    if chem == "GA":
        gamma = -2.5409 * 10 ** (-5) * c ** 3 + 0.0047889 * c ** 2 - 0.39253 * c + 73.667
    if chem == "AN":
        gamma = 0.003396 * c ** 2 + 0.1825 * c + 72.514
    if chem == "SA":
        # gamma = -3.487*10**(-10)*c**6+8.408*10**(-8)*c**5-7.975*10**(-6)*c**4+0.0003*c**3-0.0039*c**2+0.0679*c+72.023
        gamma = - 6.9564 * 10 ** (-7) * c ** 4 + 4.3729 * 10 ** (-5) * c ** 3 + 3.4601 * 10 ** (
            -5) * c ** 2 + 0.054648 * c + 72.003
    return gamma / 1000


def dens_versus_concentration(chem, c):
    c = c * 100
    if chem == "TEG" or chem == "TEGMBE":
        rho = -2.8794 * 0.000001 * c ** 2 + 0.0015247 * c + 1.0121
    if chem == "GA":
        rho = 1.026 * 10 ** (-5) * c ** 2 + 0.0021521 * c + 1.0062
    if chem == "AN":
        rho = 9 * 0.00001 * c ** 2 + 0.00405 * c + 0.9971
    if chem == "SA":
        rho = 3.8106 * 10 ** (-5) * c ** 2 + 5.9746 * 10 ** (-3) * c + 0.99970
        # rho = 3.902 * 0.00001 * c ** 2 - 0.0137 * c + 1.9807
    return rho * 1000


def pres_part_0(chem, c):
    c = c * 100
    if chem == "TEG":
        # p = -1.1606 * 10 ** (-8) * c ** 5 + 2.1913 * 10 ** (-6) * c ** 4 - 1.5750 * 10 ** (-4) * c ** 3 + 3.5989 * 0.001 * c ** 2 - 3.8316 * 0.01 * c + 22.224
        # p = -1.161 * 10 ** (-8) * c ** 5 + 2.191 * 10 ** (
        #     -6) * c ** 4 - 0.0002 * c ** 3 + 0.0036 * c ** 2 - 0.0383 * c + 22.224
        p = 2961 + -0.152 * c ** 2 + 7.79 * 10 ** (-6) * c ** 4 + -1.71 * 10 ** (-9) * c ** 6 - 5.11 * 10 ** (
            -14) * c ** 8
        const = 1
        # const = 133.32239  # mmHg in Pa
    if chem == "TEGMBE":
        # p = -1.1606 * 10 ** (-8) * c ** 5 + 2.1913 * 10 ** (-6) * c ** 4 - 1.5750 * 10 ** (-4) * c ** 3 + 3.5989 * 0.001 * c ** 2 - 3.8316 * 0.01 * c + 22.224
        # p = -1.161 * 10 ** (-8) * c ** 5 + 2.191 * 10 ** (
        #     -6) * c ** 4 - 0.0002 * c ** 3 + 0.0036 * c ** 2 - 0.0383 * c + 22.224
        p = 2978 + -36.1 * c + 4.44 * c ** 2 + -0.189 * c ** 3 + 3.83 * 10 ** (-3) * c ** 4 + -3.63 * 10 ** (
            -5) * c ** 5 + 1.25 * 10 ** (-7) * c ** 6
        # p = 2961 + -0.152*c**2 + 7.79*10**(-6)*c**4 + -1.71*10**(-9)*c**6 -5.11*10**(-14)*c**8
        const = 1
    if chem == "GA":
        # p = 4.27*10**(-6)*np.exp(0.0412*c)
        # p = -0.0002*c**4+0.0336*c**3-2.7684*c**2+99.212*c+649.5
        # !!p_last = -0.0112 * c ** 3 + 1.5943 * c ** 2 -79.451 * c + 3202.8
        p = -5.6669 * 10 ** (-8) * c ** 6 + +1.457 * 10 ** (-5) * c ** 5 - 1.4751 * 10 ** (
            -3) * c ** 4 + 7.141 * 0.01 * c ** 3 - 1.7331 * c ** 2 + 1.2029 * 10 * c + 3.1455 * 1000
        # p = 1.397*10**(-10)*c**4-3.407*10**(-8)*c**3+3.049*10**(-6)*c**2-0.0001*c+0.0016
        const = 1
    if chem == "AN":
        # p = -0.0029*c**2+0.0066*c+31.715
        # const = 133.32239  # mmHg in Pa
        p = -0.3844 * c ** 2 + 0.8784 * c + 4227.6
        const = 1
    if chem == "SA":
        # p = -4.648*10**(-11)*c**5+1.074*10**(-8)*c**4-7.272*10**(-7)*c**3 +1.759*10**(-5)*c**2-0.0003*c+0.0246
        # p = -4.1337 * 10 ** (-6) * c ** 5 + 0.9726 * 10 ** (-3) * c ** 4 - 7.2725 * 10 ** (
        #     -2) * c ** 3 + 1.7589 * c ** 2 - 34.431 * c + 2456.9
        p = 2473 - 37.4 * c + 1.92 * c ** 2 - 0.0764 * c ** 3 + 1.01 * 0.001 * c ** 4 - 4.29 * 10 ** (-6) * c ** 5
        # print(c, p)
        const = 1  # bar in Pa
    return p * const


# print(pres_part_0("TEG", 1))

def pres_part_1(theta, lk, wet_m):
    # print("-*"*50, lk)
    theta = float(theta / 180 * np.pi)
    # kappa = - (1 / np.cos(theta) - 1) ** -1
    # kappa = pp1.calc_kappa_one(theta)
    # kappa = pp1.calc_kappa_one_mod(theta)
    # print("*"*20, theta, wet_m)
    kappa = geometry.kappa_for_one_angle(theta, wet_m)
    # print("fappa", kappa)
    lk = lk * 10 ** 9 / (14)  # nm /m
    return math.exp(0.5 * kappa * lk)


def calc_wet_angle(wet_angle, c_m, chem):
    wet_new = wet_angle
    # print(wet_angle)
    wet_water = 119
    if chem == "TEG":
        wet_new = (c_m - 1) / (0.529 - 1) * (38 - 7) + 7
    if chem == "TEGMBE":
        wet_new = (c_m - 1) / (0.80457 - 1) * (38 - 7) + 7
    if chem == "SA":
        # mass_fraction = 0.78 * 98.079 / (0.78 * 98.079 + 0.22 * 18.01528)
        wet_new = (c_m - 0.65) / (0.176 - 0.65) * (48.9 - 34) + 34
    if chem == "AN":
        wet_new = (c_m - 1) / (0.6707 - 1) * (49 - 54) + 54
    if chem == "GA":
        wet_new = (c_m - 1) / (0.4752 - 1) * (31 - 35) + 35
    return wet_new


def calc_full_pressure(neck_angle, step0_angle, step1_angle, chem, T, alpha, wet_angle):
    chem_info_one = read_data.chem_info(chem, alpha)
    print("info", chem_info_one)
    dens_cond = chem_info_one["density"]  # kg/m^3
    vol_cond = geometry.calc_volume_for_one_theta(step0_angle, wet_angle) - calc_vol(neck_angle)
    mass_cond = dens_cond * vol_cond

    dens_water = water_density(T)  # kg/m^3
    vol_water = geometry.calc_volume_for_one_theta(step1_angle, wet_angle) - geometry.calc_volume_for_one_theta(
        step0_angle, wet_angle)
    print("....angle", step1_angle, step0_angle)
    mass_water = dens_water * vol_water

    c_m = mass_cond / (mass_cond + mass_water)
    print("....mass concentration ", c_m)
    wet_m = calc_wet_angle(wet_angle, c_m, chem)
    print("...wetting angle", wet_m)

    lk = calc_lk(chem_info_one, T, c_m, chem)
    p_0 = pres_part_0(chem, c_m)
    print("....pressure 0:", p_0)

    # p_1 = pres_part_1(step1_angle, chem_info_one["l_k"] )
    p_1 = pres_part_1(step1_angle, lk, wet_m)
    print("....pressure 1:", p_1)
    # print("SA", dens_versus_concentration("SA", 1))
    p_full = p_0 * p_1

    # # density
    # rho = dens_versus_concentration(chem, c)
    return p_full


def calc_full_pressure_SA(neck_angle, step00_angle, step1_angle, chem, T, alpha, wet_angle):
    chem_info_one = read_data.chem_info(chem, alpha)
    print("info", chem_info_one)
    dens_cond = chem_info_one["density"]  # kg/m^3
    print("....density", dens_cond, water_density(T))
    print("....wet_angle new", wet_angle)
    dens_water = water_density(T)  # kg/m^3

    mass_fraction = 0.65
    # 0.78 * 98.079/ (0.78 * 98.079+ 0.22 *18.01528) #Msa/ M_total
    print('....mass fraction', mass_fraction)
    volume_fraction = (1 - mass_fraction) / mass_fraction * dens_cond / water_density(T)  # V_w/V_sa
    print('....volume_fraction', volume_fraction)

    vol_00 = geometry.calc_volume_for_one_theta(step00_angle, wet_angle)
    vol_cond = (vol_00 - calc_vol(neck_angle)) / (volume_fraction + 1)
    mass_cond = dens_cond * vol_cond

    real_volume = vol_cond + calc_vol(neck_angle)
    step0_angle = geometry.calc_filling_angle_for_one_volume_and_wet_angle(real_volume, wet_angle)

    vol_water = geometry.calc_volume_for_one_theta(step1_angle, wet_angle) - real_volume
    print(geometry.calc_volume_for_one_theta(step1_angle, wet_angle), vol_water)
    print("....angle", step1_angle, step0_angle / np.pi * 180, step00_angle / np.pi * 180)
    mass_water = dens_water * vol_water

    c_m = mass_cond / (mass_cond + mass_water)
    print("....mass concentration ", c_m)
    wet_m = calc_wet_angle(wet_angle, c_m, chem)
    print("...wetting angle", wet_m)

    lk = calc_lk(chem_info_one, T, c_m, chem)
    p_0 = pres_part_0(chem, c_m)
    print("....pressure 0:", p_0)

    # p_1 = pres_part_1(step1_angle, chem_info_one["l_k"] )
    p_1 = pres_part_1(step1_angle, lk, wet_m)
    print("....pressure 1:", p_1)
    p_full = p_0 * p_1

    # # density
    # rho = dens_versus_concentration(chem, c)
    return p_full


def antoine_eq_water(T):
    A = 5.40221
    B = 1838.675
    C = -31.737
    P = 10 ** (A - B / (T + C))  # bar
    P = P * 10 ** 5  # pa
    print("P water", P)
    return P


# antoine_eq_water(290.9)

def read_DOS():
    data_in = np.loadtxt("input_1/info_Gfd_DOS_extra", usecols=(0, 1))
    return data_in


def find_exit_angle_from_Gfm(exit_angle_Gfm, RH):
    set_RH = [5, 20, 40, 65, 85]
    set_angle = exit_angle_Gfm[0]
    for i in range(len(set_RH)):
        if RH == set_RH[i]:
            angle = set_angle[i]
    return angle


def main(alpha, chem, neck_angle, wet_angle, exit_angle_1, RH):
    info_DOS = read_DOS()

    plt.clf()
    # RH = 85 # relative humidity from the set [5, 20, 40, 65, 85 ]
    # temp_chem = {"TEG": 297, "AN": 303, "SA": 293, "TEGMBE": 297, "GA": 291}
    temp_chem = {"TEG": 298, "AN": 298, "SA": 297, "TEGMBE": 298, "GA": 298}
    print("-*" * 40)
    print("for ", chem, " and RH = ", RH, "%")
    temp = temp_chem[chem]

    # angles
    step0_angle = exit_angle_1
    step1_angle = step0_angle
    # step1_angle = find_exit_angle_from_Gfm(exit_angle_GFV[chem], RH)
    print("     angles: ", " neck -", round(neck_angle, 2), " after cond.-", round(step0_angle, 2), " after Gfv-",
          round(step1_angle, 2))

    # initial conditions
    p_sat_100_water = antoine_eq_water(temp)
    p_sat_rh_water = p_sat_100_water * RH / 100
    print("water pressure for rh = 100% ", round(p_sat_100_water, 2), " Pa")
    print("water pressure for rh = ", RH, "% ", round(p_sat_rh_water, 2), " Pa")
    if chem != 'SA':
        p_mix = calc_full_pressure(neck_angle, step0_angle, step1_angle, chem, temp, alpha, wet_angle)
    if chem == 'SA':
        p_mix = calc_full_pressure_SA(neck_angle, step0_angle, step1_angle, chem, temp, alpha, wet_angle)
    print("*** START mix pressure for rh ", RH, "% = ", round(p_mix, 2), "Pa")

    set_angles = [step1_angle]
    set_pressure = [p_mix]
    set_rh = [p_mix / p_sat_100_water * 100]
    angle_step = 0.05
    while p_mix < p_sat_rh_water:
        step1_angle = step1_angle + angle_step
        if chem != 'SA':
            p_mix = calc_full_pressure(neck_angle, step0_angle, step1_angle, chem, temp, alpha, wet_angle)
        if chem == 'SA':
            p_mix = calc_full_pressure_SA(neck_angle, step0_angle, step1_angle, chem, temp, alpha, wet_angle)
        set_angles.append(step1_angle)
        set_pressure.append(p_mix)
        set_rh.append(p_mix / p_sat_100_water * 100)
    print("*** END mix pressure for rh = ", RH, "% ", round(p_mix, 2), "Pa", " with angle ", round(step1_angle, 2))

    set3 = check_rh_range(5, set_angles, set_pressure, set_rh)
    exit_angle = set3

    name_file_rh_angle = str(
        "output/FILLING_ANGLE_vs_RH/chem_" + str(chem) + "_neck_" + str(neck_angle) + "_alpha_" + str(
            alpha) + "_RH_" + str(RH) + "_final_angle_GAP")
    write_file_rh_vs_angle(exit_angle, chem, name_file_rh_angle)

    # plt.plot(exit_angle[2], exit_angle[0])
    # plt.show()

    # list_exit_angles = []
    # for i in set_chem:
    #     one_angle = set_exit_angle[i][0][-1]
    #     list_exit_angles.append([i, round(one_angle,2)])
    # write_exit_angle(list_exit_angles, alpha, neck_angle, RH)
    #
    # color_step = 1/6
    # for i in range(len(chem_info)):
    #     chem = set_chem[i]
    #     one_chem = set_exit_angle[chem]
    #     # one_chem = set_pressure[chem]
    #     plt.plot(one_chem[0], one_chem[2], color=(0.0 + i * color_step, 0.5 - i * color_step / 2, 1.0 - i * color_step), label = chem)
    #
    # plt.axhline(y=RH, color='k', linestyle='--')
    #
    # plt.xlim([0, 90])
    # plt.xlabel(r'exit angle, $\theta_2$ (degree)')
    # plt.ylabel(r'relative humidity ($\%$)')
    # # file_name = "output/KELVIN_All" + "_alpha_" + str(alpha) + ".pdf"
    # file_name = "output/KELVIN_All" + "_alpha_" + str(alpha) + ".png"
    # plt.legend(loc='best')
    # plt.savefig(file_name)
    # plt.show()
    # return list_exit_angles
