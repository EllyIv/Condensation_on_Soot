def main(a):
    kB = 1.380649e-23  # J/K
    R_gas = 8.314  # J/mol/K

    # Parameters
    T = 273 + 24  # K
    R_s = 14 * 1e-9  # m
    const_a = 1 # for MBE

    const_dict = {'kB': kB, 'R_gas': R_gas, 'T': T , 'R_s':R_s, 'const_a': const_a }

    return const_dict[a]


# def press_1(chem):
#     press_dict = {"GA": 0.000248, "AN": 0.00126, "SA": 0.00000316}
#     return press_dict[chem]
#
# def press_2(chem):
#     press_dict = {"GA": 0.000922, "AN": 0.00298, "SA": 0.000000238}
#     return press_dict[chem]


def press_1(chem):
    press_dict = {"GA": 0.00017, "AN": 0.00126, "SA": 0.0000000123, "SA0": 0.00000316}
    return press_dict[chem]

def press_2(chem):
    press_dict = {"GA": 0.001000, "AN": 0.00298, "SA": 0.00000000208, "SA0": 0.000000238}
    return press_dict[chem]
    
def zeta_AN():
	return 0.487