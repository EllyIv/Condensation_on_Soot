import numpy as np
import math
import PARAMETERS as param
from scipy import constants as const

########################################################################################################################
kB = const.k  # 1.38E-23 # J/K
R_gas = const.R  # 8.31 # J/k*mol
N_A = const.N_A  # 6.02E23
R_s = param.main('R_s')
T = param.main('T')


########################################################################################################################
# READ DATA
########################################################################################################################
def info_lit():
    name_file = "input_0/info_chem.txt"

    f = open(name_file, "r")
    lines = f.readlines()
    lines = lines[3:]
    set_chem = []
    for line in lines:
        chem = line.split("\t\t")[0]
        set_chem.append(chem)
    f.close()

    # chem data
    # mol.mass,      density,	surf.tens.,	boil.point	vap.pres.,     Kel.len.
    data_in = np.loadtxt(name_file, skiprows=3, usecols=(1, 2, 3, 4, 5, 6,))

    # see_table(set_chem, data_in)
    return [set_chem, data_in]


########################################################################################################################
# CALC EXTRA PROPERTIES
#####################################################################################################################
def get_zeta(chem, alpha, prnt):
    if chem == "TEG" or chem == "TEGMBE" or chem == "PA":
        zeta = alpha - 1
    if chem == "AN":
        zeta = param.zeta_AN() * alpha - 1
    if chem == "GA":
        zeta = param.press_1(chem) / param.press_2(chem) * alpha - 1
    if chem == "SA":
        zeta = param.press_1(chem) / param.press_2(chem) * alpha - 1
    if chem == "TDA":
        zeta = alpha - 1
    if prnt == "yes":
        print("*calculate zeta*")
        print("                = ", round(zeta, 3))
    return round(zeta, 3)


def n_inf(Psat):
    n = Psat / kB / T
    return n


# Calc P_0 (in Pa)
def P_0(Psat, alpha, zeta):
    P = (zeta + 1) * Psat / alpha
    return P


# Calc vT (in m/s)
def v_T(M):
    v = math.sqrt(8 * R_gas * T / (math.pi * M))
    return v


# Calc n_l (in m^-3)
def n_l(gamma, lK):
    nl = 2 * gamma / (lK * T * kB)
    return nl


def n_0_max(zeta, n_inf, alpha):  # n0 calculations given zeta value
    n = (zeta + 1) * n_inf / alpha
    return n


def n_0(n_0_max, alpha):  # n0 calculations given zeta value
    n = n_0_max * alpha
    return n


#####################################################################################################################
# CREATE DICTIONARY
#####################################################################################################################
def list_to_dict(chem, info_chem, alpha, zeta, prnt):
    dict_info = {}

    dict_info["zeta"] = float(zeta)  # kg/mol
    dict_info["mol_mass"] = float(info_chem[0]) * 0.001  # kg/mol
    dict_info["density"] = float(info_chem[1]) * 0.001 * 1e6  # kg m−3
    dict_info["surf_tens"] = float(info_chem[2]) * 0.001  # N/m
    dict_info["boil_point"] = float(info_chem[3])  # C
    dict_info["P_inf"] = float(info_chem[4])  # Pa = N/ m^2
    dict_info["P_0"] = P_0(dict_info["P_inf"], alpha, zeta)  # Pa
    dict_info["l_k"] = float(info_chem[5]) * 1e-9  # m
    dict_info["n_inf"] = n_inf(dict_info["P_inf"])  # m^-3
    dict_info["n_0_max"] = n_0_max(zeta, dict_info["n_inf"], alpha)  # m^-3
    dict_info["n_0"] = n_0(dict_info["n_0_max"], alpha)  # m^-3
    dict_info["v_t"] = v_T(dict_info["mol_mass"])  # m/s
    dict_info["n_l"] = n_l(dict_info["surf_tens"], dict_info["l_k"])  # m^-3
    dict_info["T"] = T
    dict_info["Rs"] = R_s
    dict_info["alpha"] = alpha

    if prnt == "yes":
        print("FOR CHEM ", chem)
        print(".../... zeta ", round(dict_info["zeta"], 6), " --")
        print(".../... molar mass ", round(dict_info["mol_mass"], 3), "kg/mol")
        print(".../... density ", round(dict_info["density"], 3), "kg/m-3")
        print(".../... surf_tens ", round(dict_info["surf_tens"], 3), "N/m")
        print(".../... boil_point ", round(dict_info["boil_point"], 3), "C")
        print(".../... P_inf ", dict_info["P_inf"], "Pa")
        print(".../... P_0 ", dict_info["P_0"], " Pa")
        print(".../... l_k ", dict_info["l_k"], "m")
        print(".../... n_inf ", dict_info["n_inf"], "m^-3")
        print(".../... n_0_max ", dict_info["n_0_max"], "m^-3")
        print(".../... n_0 ", dict_info["n_0"], "m^-3")
        print(".../... v_t ", dict_info["v_t"], "m/s")
        print(".../... n_l ", dict_info["n_l"], "m^-3")
    print("*data are ready and saved*")
    return dict_info


#####################################################################################################################
# WRITE INTO FILE ALL WHAT WE USE
#####################################################################################################################
def write_into_file(info_chem, chem, alpha):
    name_file = "input_1/info_" + str(chem) + "_alpha_" + str(alpha) + ".txt"
    file = open(name_file, "w")

    file.write("*** units *** \n")
    dict_units = {'zeta': "-", "mol_mass": "kg/mol", "density": "kg/m-3", "surf_tens": "N/m", "boil_point": "C",
                  "P_inf": "Pa", "l_k": "m", "n_inf": "m^-3", "n_0_max": "m^-3", "n_0": "m^-3", "v_t": "m/s",
                  "n_l": "m^-3"}
    units_line_1 = "  " + '     '.join(list(dict_units.keys())) + "\n"
    units_line_2 = "  " + '     '.join(list(dict_units.values())) + "\n"
    file.write(units_line_1)
    file.write(units_line_2)

    file.write("\n")
    file.write("*** info *** \n")
    first_line = ' '.join(list(info_chem.keys())) + "\n"
    file.write(first_line)
    second_line = ' '.join(str(number) for number in list(info_chem.values())) + "\n"
    file.write(second_line)

    file.close()


########################################################################################################################
########################################################################################################################
########################################################################################################################
def main(alpha, chem):
    # read data from paper Chen 2018
    LIT_info = info_lit()

    # calculate zeta for considered conditions
    zeta = get_zeta(chem, alpha, "yes")  # print option "yes/no"

    # find chem in a literature
    number_chem = LIT_info[0][:].index(chem)
    part_info_chem = LIT_info[1][number_chem]

    # create dictionary wih information about considered chemicals
    info_chem = list_to_dict(chem, part_info_chem, alpha, zeta, "yes")  # print option "yes/no"

    write_into_file(info_chem, chem, alpha)
