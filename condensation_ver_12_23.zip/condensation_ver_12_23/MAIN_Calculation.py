import P0_READ_DATA as read_data

import P1_MBE as mbe
import P1__get_info as get_info
import P1__analysis_of_mbe as pre_mbe

import P2_SOOT_NECK as neck
import P2__exit_angle as exit_angle

import P3_GFV_2018 as gfd_gfv
import P3_KELVIN as kelvin_effect

import P4_Gfd_exp as gfd
import P4_Gfm_exp as gfm

########################################################################################################################
########################################################################################################################
"""
Considered compounds only: 'TEG', 'TEGMBE', 'GA', 'SA', 'AN', 'TDA', 'PA'
(same as in the experiment)

before starting
       only once:
       3. creat a folder 'output/GEOMETRY_of_the_liquid_bridge'
       4. go to catenoid_matrix. run GEOM_cat_full_T.generate_catenoid()
       5. go to P0_GEOM and run calc_geometry_for_wetting_angle(wet_deg)


Program considers condensation of the compounds on soot surface for specific scenario       

    :parameter
    set_chem - selected compounds , scenario, set_kappa, set_N
    scenario - selected scenario (from 1 to 100)
    set_kappa -  it is for kappa theory
    set_N - amount of monomers in one aggregate (for kappa theory)
"""

########################################################################################################################
########################################################################################################################
dict_wetting_angle = {'TEG': 7, 'TEGMBE': 7, 'GA': 35, 'AN': 54, 'SA': 34, 'TDA': 0, 'PA': 0}

chem_lab = {'TEG', 'TEGMBE', 'GA', 'SA', 'AN', 'TDA', 'PA'}

chem = "AN"  # considered chem / [TEG, TEGMBE AN, GA, SA]
alpha = 0.9  # -- / percent of the chem in a chamber / 0-1
neck_angle_deg = 10  # degree / neck of the soot / <90
wetting_angle_deg = dict_wetting_angle[chem]  # degree / wetting angle with soot surface / <90

print("*" * 20)
print("*" * 20)
print("You consider ...")
print("             ... chemical      = ", chem)
print("             ... alpha         = ", alpha, " (-)")
print("             ... neck_angle    = ", neck_angle_deg, " (degree)")
print("             ... wetting_angle = ", wetting_angle_deg, " (degree)")
print("*" * 20)
print("*" * 20)

########################################################################################################################
# Preparation. read main info
########################################################################################################################
print("-" * 100)
print("PART 0: Preparation")
print('     - get all information about chemical')
print('     - generate catenoid geometry')
print("-" * 100)
get_info.main(alpha, chem)

########################################################################################################################
# STAGE I
# Amount of condensed liquid considered based on MBE.
# As a geometry of the liquid bridge we consider globoid with 2 radii
########################################################################################################################
print("-" * 100)
print("PART 1: COND/EVAP ANALISIS")
print("-" * 100)
chem_info = read_data.chem_info(chem, alpha)
set_proc = pre_mbe.main(chem_info, wetting_angle_deg)

print("-" * 100)
print("PART 2: CALC FILLING ANGLE")
print("-" * 100)
mbe.main(chem, chem_info, set_proc, wetting_angle_deg)
angle_without_neck = read_data.read_angle_info(alpha, chem, wetting_angle_deg)

print("-" * 100)
print("PART *: EXIT ANGLE")
print("-" * 100)
exit_angle_without_neck = exit_angle.main(alpha, chem, angle_without_neck, 0,
                                          wetting_angle_deg)  # 0 corresponds to the neck

print("-" * 100)
print("PART 4: CONSIDER NECK")
print("-" * 100)
angle_info_1 = neck.main(alpha, chem, angle_without_neck, neck_angle_deg, wetting_angle_deg)

print("-" * 100)
print("PART *: EXIT ANGLE")
print("-" * 100)
exit_angle_1 = exit_angle.main(alpha, chem, angle_info_1, neck_angle_deg, wetting_angle_deg)

print("-" * 100)
print("PART 5: GFD/GFV")
print("-" * 100)
angle_info_2 = gfd_gfv.main(alpha, chem, neck_angle_deg, wetting_angle_deg)

print("-" * 100)
print("PART *: ADDING WATER")
print("-" * 100)
exit_angle_2 = kelvin_effect.main(alpha, chem, neck_angle_deg, wetting_angle_deg, exit_angle_1, 85)

print("-" * 100)
print("PART *: Gfd")
print("-" * 100)
gfd.main(alpha, chem, neck_angle_deg, wetting_angle_deg)

print("-" * 100)
print("PART *: Gfm")
print("-" * 100)
gfm.main(alpha, chem, neck_angle_deg, wetting_angle_deg, chem_info["density"])
