import numpy as np

######################################################################################################################
def chem_info(chem , alpha):
    name_file = "input_1/info_"+str(chem)+"_alpha_"+str(alpha)+".txt"
    f = open(name_file, "r")
    lines = f.readlines()

    dict_info = {}
    properties = lines[5][:-1].split(" ")
    value = lines[6][:-1].split(" ")

    for i in range(len(properties)):
        dict_info[properties[i]] = float(value[i])

    return dict_info
######################################################################################################################


def read_angle_info(alpha, chem, wet_deg):
    """
    choice units for time and amount of liquid
    """
    print("read info ... choice units reduced/nonreduced")
    units = "halfREDUCED"  # "REDUCED, nonREDUCED, halfREDUCED"


    if units == "REDUCED":
        file_name_N = "output/COND_AMOUNT_without_neck/FOR_" + chem + "_alpha_" + str(alpha) + "_wet_" + str(
        round(wet_deg, 3)) + "_REDUCED_DATA.txt"
        file_name_T ="output/FILLING_ANGLE_without_neck/FOR_" + chem + "_alpha_" + str(
        alpha) + "_wet_" + str(round(wet_deg, 3)) + "_REDUCED_DATA.txt"
    if units == "nonREDUCED":
        file_name_N = "output/COND_AMOUNT_without_neck/FOR_" + chem + "_alpha_" + str(alpha) + "_wet_" + str(
        round(wet_deg, 3)) + "_nonREDUCED_DATA.txt"
        file_name_T = "output/FILLING_ANGLE_without_neck/FOR_" + chem + "_alpha_" + str(
        alpha) + "_wet_" + str(round(wet_deg, 3)) + "_nonREDUCED_DATA.txt"
    if units == "halfREDUCED":
        file_name_N = "output/COND_AMOUNT_without_neck/FOR_" + chem + "_alpha_" + str(alpha) + "_wet_" + str(
        round(wet_deg, 3)) + "_halfREDUCED_DATA.txt"
        file_name_T = "output/FILLING_ANGLE_without_neck/FOR_" + chem + "_alpha_" + str(
        alpha) + "_wet_" + str(round(wet_deg, 3)) + "_nonREDUCED_DATA.txt"

    info_T = np.loadtxt(file_name_T, usecols=[0, 1])


    # extensiion over time in a chaber , should be ore than 25 sec
    time = info_T[:, 0]
    angle = info_T[:, 1]

    last_time = time[-1]
    last_angle = angle[-1]

    new_info = []
    for j in range(len(time)):
        new_info.append([time[j], angle[j]])

    if last_time <= 30:
        add_time = np.arange(last_time, 30, 0.01)
        for t in add_time:
            new_info.append([t, last_angle])

    return np.array(new_info)