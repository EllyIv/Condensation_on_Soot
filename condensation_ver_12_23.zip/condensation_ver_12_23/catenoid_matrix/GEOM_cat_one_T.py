import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_bvp

"""
Find geometry of the liquid CATENOID profile between two sphere with radius  = 1
    input:  theta - filling angle (degree)
            phi - wetting angle (degree)
            d - distance between spheres

    output: y(x) - shape of the profile 
            kappa - curvature 
            a - area of the surface 
            vol - volume  
                    
"""
# additional function for solve_bvp
def mat4ode(x, y, kappa_):
    dydx = np.vstack((y[1], (1 + y[1] ** 2) ** (3 / 2) * (2 * kappa_[0] + 1 / (y[0] * (1 + y[1] ** 2) ** (1 / 2)))))
    return dydx

# additional function for solve_bvp
def mat4bc(ya, yb, kappa_):
    res = np.array([ya[0] - np.sin(theta_rad), ya[1] + np.tan(np.pi / 2 - theta_rad- phi_rad), yb[1]])
    return res

# calculation of catenoid volume
def calc_volume(x_values, y_values):
    integrand = np.pi * y_values ** 2
    vol_cap = np.pi * 1 / 3 * (np.cos(theta_rad) - 1) ** 2 * (2 + np.cos(theta_rad))
    vol = np.trapz(integrand, x_values) - 2 * vol_cap
    return vol

# calculation of catenoid area
def calc_area(x_values, y_values):
    dy_dx = np.gradient(y_values, x_values)
    integrand = 2 * np.pi * y_values * np.sqrt(1 + (dy_dx) ** 2)
    area = np.trapz(integrand, x_values)
    return area

########################################
########################################
########################################
def main(theta, phi, d, prnt):
    # print(f"Consider CATENOID for {theta:7.0f}  filling angle and {phi:7.0f} wetting angle")
    global theta_rad
    global phi_rad
    theta_rad = theta / 180 * np.pi
    phi_rad = phi / 180 * np.pi

    kappa_ = np.array([0])  # Initial guess for kappa

    x = np.linspace(0, 1 - np.cos(theta_rad) + d/2, 200)  # range for x
    y = np.zeros((2, x.size))
    y[0] = np.sin(theta_rad)  # Initialize y[0] with the desired value

    sol = solve_bvp(mat4ode, mat4bc, x, y, p=kappa_)
    curvature = sol.p[0]

    x_1 = np.linspace(0, 1 - np.cos(theta_rad)+ d/2)
    y_1 = sol.sol(x_1)[0]
    y_1_prime = sol.sol(x_1)[1]

    step_size = x_1[1] - x_1[0]

    y_2 = np.flip(y_1)[1:]
    y_cat = np.concatenate((y_1, y_2))

    x_cat = list(x_1)
    for i in range(len(x_1) - 1):
        x_cat.append(x_1[-1] + step_size * (i + 1))

    if prnt == 0:
        plt.plot(x_cat, y_cat, label="y'")
        # plt.axis([0, 2-2 * np.cos(theta_rad), 0, 1])
        plt.xlabel("x")
        plt.ylabel("y")
        plt.legend()
        plt.show()

    vol = calc_volume(x_cat, y_cat)
    area = calc_area(x_cat, y_cat)
    return [curvature, vol, area, [x_cat, y_cat]]

# main(80, 85, 0, 0) # theta, phi, d, prnt (prnt ==0 -> print profile)
