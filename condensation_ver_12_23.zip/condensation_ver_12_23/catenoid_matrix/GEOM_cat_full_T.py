import GEOM_cat_one_T as cat
import numpy as np
import matplotlib.pyplot as plt

def main(phi, dist):
    theta_set = np.linspace(5, 90, 171)
    kappa_set = []
    vol_set = []
    area_set = []
    for theta in theta_set:
        info = cat.main(theta, phi, dist, 1)
        kappa = info[0]
        vol = info[1]
        area = info[2]
        kappa_set.append(-kappa)
        vol_set.append(vol)
        area_set.append(area)

    theta_set_rad = theta_set / 180 * np.pi
    d_vol_set = np.gradient(vol_set, theta_set_rad)

    return [theta_set, vol_set, d_vol_set, area_set, kappa_set]


def generate_catenoid():
    """
    generate txt-files for catenoid geometry (curvature/area/volume/d_volume)
    as a matrix (filling angle/wetting angle)

    theta (from 5 till 90 with step 0.5) - > column
    phi (from 0 till 89 with step 1) - > row
    """
    phi_set = np.linspace(0, 89, 90)  # possible wetting angle, degree
    file_set = ["catenoid_volume.txt", "catenoid_dvolume.txt", "catenoid_area.txt", "catenoid_kappa.txt"]
    for f in range(len(file_set)):
        file = open(file_set[f], "w")
        for i in range(len(phi_set)):
            phi = phi_set[i]
            f_info = main(phi, 0)
            line_str = ' '.join(map(str, f_info[f + 1])) + '\n'
            file.write(line_str)
        file.close()


def check_catenoid(phi_fix_deg, geom_str, prnt):
    """
    Function to check  geometry of the catenoid for specific wetting angle
    """
    geom_dict = {'volume':0 , 'd_volume' :1, 'area':2 , 'kappa':3}
    geom = geom_dict[geom_str]
    path = '/Users/elly/PycharmProjects/Using_NETCDF_ATM_DATA/catenoid_matrix/'
    file_set = ["catenoid_volume.txt", "catenoid_dvolume.txt", "catenoid_area.txt", "catenoid_kappa.txt"]
    info = np.loadtxt(path+file_set[geom])

    theta_set = np.linspace(5, 90, 171)  # possible filling angle
    phi_set = np.linspace(0, 89, 90)  # possible wetting angle

    phi_fix_deg = round(phi_fix_deg, 0)
    index_fix = np.where(phi_set == phi_fix_deg)

    if prnt == 0:
        plt.plot(theta_set, info[index_fix][0])
        plt.show()
    return [theta_set, info[index_fix][0]]


# generate_catenoid()
# check_catenoid(0, 'kappa', 0)  # phi_fix (degree), 'volume':0 , 'd_volume' :1, 'area':2 , 'kappa':4
