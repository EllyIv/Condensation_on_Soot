import numpy as np


# we can have a trouble when fil angle + wet angle = 90, because the profile will change, but we never reached this point in our situations
# so no worries. no change of geometry

#####################################################################################################################
#####################################################################################################################
def func_a(theta):
    return 1


def func_b(theta):
    return np.tan(theta)


def func_c(theta):
    return 1 / np.cos(theta) - 1


# calculation of the curvature for one filling angle and one wetting angle
def kappa_for_one_angle(fil_rad, wet_deg):
    wet_rad = wet_deg / 180 * np.pi
    if wet_rad == 0.0:
        x_in = np.cos(fil_rad)
        x_out = 1
        x_range = np.linspace(x_in, x_out, 11)
        r_in = func_b(fil_rad) - (func_c(fil_rad) ** 2 - (x_range - 1) ** 2) ** 0.5

        r_out = func_c(fil_rad)
        r_full = - 1 / r_out + 1 / r_in
        yint = np.trapz(r_full, x=x_range) / (x_out - x_in)

    if wet_rad != 0.0:
        x_in = np.cos(fil_rad)
        x_out = 1
        xr = np.linspace(x_in, x_out, 11)
        r_out = (1 - np.cos(fil_rad)) / np.cos(wet_rad + fil_rad)
        r_in = r_out * np.sin(wet_rad + fil_rad) + np.sin(fil_rad) - (r_out ** 2 - (1 - xr) ** 2) ** 0.5
        r_full = -1 / r_out + 1 / r_in
        yint = np.trapz(r_full, x=xr) / (x_out - x_in)
    return yint


# calculation set of the curvatures for range of filling angles and one wetting angle
def kappa_for_multi_angles(filling_angle_range_rad, wetting_angle_deg):
    set_kappa = []
    for filling_angle in filling_angle_range_rad:
        set_kappa.append(kappa_for_one_angle(filling_angle, wetting_angle_deg))

    return np.array(set_kappa)


#####################################################################################################################
#####################################################################################################################

def calc_geometry_for_wetting_angle(wet_deg):
    wet_rad = wet_deg / 180 * np.pi
    theta = np.linspace(0.0001, np.pi / 2 - 0.0001 - wet_rad, 10000)

    area_for_theta = []
    volume_for_theta = []
    kappa_for_theta = []

    for the in theta:
        a = 0
        b = 1 - np.cos(the)
        x = np.linspace(a, b, 100)

        rc = (1 - np.cos(the)) / np.cos(the + wet_rad)
        H = rc * np.sin(the + wet_rad) + np.sin(the)

        y = H - (rc ** 2 - x ** 2) ** 0.5
        diff_y = x / (rc ** 2 - x ** 2) ** 0.5
        pre_int = y * (1 + diff_y ** 2) ** 0.5

        half_area = 2 * np.pi * np.trapz(pre_int, x=x)
        full_area = 2 * half_area
        area_for_theta.append(full_area)

        half_volume = np.pi * np.trapz(y ** 2, x=x)
        Vcap = np.pi / 3 * (np.cos(the) - 1) ** 2 * (2 + np.cos(the))
        full_volume = 2 * half_volume - 2 * Vcap
        volume_for_theta.append(full_volume)

        kappa = np.array(kappa_for_one_angle(the, float(wet_deg)))
        kappa_for_theta.append(kappa)

    diff_volume_for_theta = np.gradient(volume_for_theta, theta)

    file_name = "output/GEOMETRY_of_the_liquid_bridge/wetting_angle_" + str(round(wet_deg, 3)) + ".txt"
    f = open(file_name, "w")
    for i in range(len(theta)):
        f.write(str(theta[i]) + " " + str(area_for_theta[i]) + " " + str(volume_for_theta[i]) + " " + str(
            diff_volume_for_theta[i]) + " " + str(kappa_for_theta[i]) + " \n")
    f.close()


def calc_volume_for_one_theta(theta_deg, wet_deg):
    wet_rad = wet_deg / 180 * np.pi
    theta_rad = theta_deg / 180 * np.pi

    a = 0
    b = 1 - np.cos(theta_rad)
    x = np.linspace(a, b, 100)

    rc = (1 - np.cos(theta_rad)) / np.cos(theta_rad + wet_rad)
    H = rc * np.sin(theta_rad + wet_rad) + np.sin(theta_rad)

    y = H - (rc ** 2 - x ** 2) ** 0.5
    # diff_y = x / (rc ** 2 - x ** 2) ** 0.5
    # pre_int = y * (1 + diff_y ** 2) ** 0.5

    half_volume = np.pi * np.trapz(y ** 2, x=x)
    Vcap = np.pi / 3 * (np.cos(theta_rad) - 1) ** 2 * (2 + np.cos(theta_rad))
    full_volume = 2 * half_volume - 2 * Vcap

    return full_volume


#####################################################################################################################
#####################################################################################################################
def calc_geometry_for_one_filling_angle(theta_0, wet_deg):
    wet_rad = wet_deg / 180 * np.pi
    theta = np.linspace(0.0001, np.pi / 2 - 0.0001 - wet_rad, 10000)
    min = 1
    min_i = 100
    diff_theta = theta - theta_0

    for i in range(len(diff_theta) - 1):
        if diff_theta[i] <= 0 and diff_theta[i + 1] > 0:
            min = theta[i]
            min_i = i

    name = "output/GEOMETRY_of_the_liquid_bridge/wetting_angle_" + str(round(wet_deg, 3)) + ".txt"
    data_in = np.loadtxt(name, skiprows=0, usecols=(0, 1, 2, 3, 4))

    t_min = data_in[min_i][0]
    t_max = data_in[min_i + 1][0]
    A_min = data_in[min_i][1]
    A_max = data_in[min_i + 1][1]
    V_min = data_in[min_i][2]
    V_max = data_in[min_i + 1][2]
    dV_min = data_in[min_i][3]
    dV_max = data_in[min_i + 1][3]
    kappa_min = data_in[min_i][4]
    kappa_max = data_in[min_i + 1][4]

    A_fix = (theta_0 - t_min) / (t_max - t_min) * (A_max - A_min) + A_min
    dV_fix = (theta_0 - t_min) / (t_max - t_min) * (dV_max - dV_min) + dV_min
    kappa_fix = (theta_0 - t_min) / (t_max - t_min) * (kappa_max - kappa_min) + kappa_min
    V_fix = (theta_0 - t_min) / (t_max - t_min) * (V_max - V_min) + V_min

    return [theta_0, A_fix, dV_fix, kappa_fix, V_fix]


def calc_theta_for_volume(volume, set_vol):
    min_i = 0
    diff_vol = np.array(set_vol) - volume
    for i in range(len(diff_vol) - 1):
        if diff_vol[i] <= 0 and diff_vol[i + 1] > 0:
            min_i = i
            # min_i = i
    return min_i


def calc_geometry_for_one_filling_angle_SA(theta_0, wet_deg):
    wet_rad = wet_deg / 180 * np.pi
    theta = np.linspace(0.0001, np.pi / 2 - 0.0001 - wet_rad, 10000)
    min = 1
    min_i = 100
    diff_theta = theta - theta_0

    for i in range(len(diff_theta) - 1):
        if diff_theta[i] <= 0 and diff_theta[i + 1] > 0:
            min = theta[i]
            min_i = i

    name = "output/GEOMETRY_of_the_liquid_bridge/wetting_angle_" + str(round(wet_deg, 3)) + ".txt"
    data_in = np.loadtxt(name, skiprows=0, usecols=(0, 1, 2, 3, 4))

    t_min = data_in[min_i][0]
    t_max = data_in[min_i + 1][0]
    V_min = data_in[min_i][2]
    V_max = data_in[min_i + 1][2]

    V_fix = (theta_0 - t_min) / (t_max - t_min) * (V_max - V_min) + V_min
    mass_fraction = 0.65
    # 0.78 * 98.079 / (0.78 * 98.079 + 0.22 * 18.01528)
    V_extra_water = V_fix * mass_fraction * 1.6 / 0.997
    V_total = V_fix + V_extra_water
    # print("yes! ", theta_0, V_fix, V_extra_water, V_total)
    theta_new = data_in[calc_theta_for_volume(V_total, data_in[:, 2])][0]

    mmin = 1
    mmin_i = 100
    ddiff_theta = theta - theta_new
    # print(theta_new)
    # print("    ")
    for i in range(len(ddiff_theta) - 1):
        if ddiff_theta[i] <= 0 and ddiff_theta[i + 1] > 0:
            mmin = theta[i]
            mmin_i = i

    t_min = data_in[mmin_i][0]
    t_max = data_in[mmin_i + 1][0]
    A_min = data_in[mmin_i][1]
    A_max = data_in[mmin_i + 1][1]
    V_min = data_in[mmin_i][2]
    V_max = data_in[mmin_i + 1][2]
    dV_min = data_in[mmin_i][3]
    dV_max = data_in[mmin_i + 1][3]
    kappa_min = data_in[mmin_i][4]
    kappa_max = data_in[mmin_i + 1][4]

    A_fix = (theta_new - t_min) / (t_max - t_min) * (A_max - A_min) + A_min
    dV_fix = (theta_new - t_min) / (t_max - t_min) * (dV_max - dV_min) + dV_min
    kappa_fix = (theta_new - t_min) / (t_max - t_min) * (kappa_max - kappa_min) + kappa_min
    V_fix = (theta_new - t_min) / (t_max - t_min) * (V_max - V_min) + V_min

    return [theta_new, A_fix, dV_fix, kappa_fix, V_fix]


def calc_filling_angle_for_one_volume_and_wet_angle(vol, wet_deg):
    # wet_rad = wet_deg / 180 * np.pi
    # theta = np.linspace(0.0001, np.pi / 2 - 0.0001 - wet_rad, 10000)
    # min = 1
    # min_i = 100
    # diff_theta = theta - theta_0
    #
    # for i in range(len(diff_theta) - 1):
    #     if diff_theta[i] <= 0 and diff_theta[i + 1] > 0:
    #         min = theta[i]
    #         min_i = i
    # print(wet_deg)
    name = "output/GEOMETRY_of_the_liquid_bridge/wetting_angle_" + str(round(wet_deg, 3)) + ".txt"
    data_in = np.loadtxt(name, skiprows=0, usecols=(0, 2))
    set_vol = data_in[:, 1]
    diff_vol = set_vol - vol

    min_i = 0
    for i in range(len(diff_vol) - 1):
        if diff_vol[i] <= 0 and diff_vol[i + 1] > 0:
            min = set_vol[i]
            min_i = i

    t_min = data_in[min_i][0]
    t_max = data_in[min_i + 1][0]
    V_min = data_in[min_i][1]
    V_max = data_in[min_i + 1][1]

    # print("new rnge:", t_min/3.14*180, t_max)

    t_fix = (vol - V_min) / (V_max - V_min) * (t_max - t_min) + t_min
    # print(t_fix)
    return t_fix
